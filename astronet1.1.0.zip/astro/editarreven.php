<?php
include("../astro/conexao.php"); // Conexão com o banco de dados

$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

// Verifica se o ID foi recebido via POST
if (!empty($_POST['id'])) {
    $id = $_POST['id'];

    // Inicializa arrays para atualização dinâmica
    $updates = [];
    $params = [];
    $types = "";

    // Lista dos campos que podem ser atualizados
    $fields = [
        'login' => 's',
        'senha' => 's',
        'whatsapp' => 's',
        'limite' => 's',
        'valor' => 's',
        'validade' => 's',
        'renovacao_periodo' => 's'
    ];

    // Percorre os campos e adiciona apenas os que foram enviados e não estão vazios
    foreach ($fields as $field => $type) {
        if (isset($_POST[$field]) && $_POST[$field] !== '') {
            $updates[] = "$field = ?";
            $params[] = $_POST[$field];
            $types .= $type;
        }
    }

    // Verifica se há algo para atualizar
    if (!empty($updates)) {
        $sql = "UPDATE accounts SET " . implode(", ", $updates) . " WHERE id = ?";
        $stmt = $conn->prepare($sql);

        if ($stmt === false) {
            echo json_encode(["status" => "error", "message" => "Erro na preparação da consulta: " . $conn->error]);
            exit();
        }

        // Adiciona o ID ao final dos parâmetros
        $params[] = $id;
        $types .= "i"; // ID é inteiro

        // Vincula os parâmetros dinamicamente
        $stmt->bind_param($types, ...$params);

        // Executa a consulta e verifica se foi bem-sucedida
        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Revenda atualizada com sucesso."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Falha ao atualizar a revenda: " . $stmt->error]);
        }

        // Fecha a declaração preparada
        $stmt->close();
    } else {
        echo json_encode(["status" => "error", "message" => "Nenhum dado para atualizar."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "ID não recebido."]);
}

// Fecha a conexão com o banco de dados
$conn->close();
?>
