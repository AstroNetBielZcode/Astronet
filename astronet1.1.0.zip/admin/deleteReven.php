<?php
include("../astro/conexao.php"); // Conexão com o banco de dados

try {
    $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
} catch (mysqli_sql_exception $e) {
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["id"])) {
    $id = intval($_POST["id"]);

    $stmt = $conn->prepare("DELETE FROM accounts WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "success"; // Retorna sucesso
    } else {
        echo "error: " . $stmt->error; // Mostra erro do MySQL
    }
    $stmt->close();
} else {
    echo "error: ID inválido"; // Caso o ID não seja enviado corretamente
}
?>
