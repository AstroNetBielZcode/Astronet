<?php
include('../astro/conexao.php');
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['id'])) {
    $usuario_id = $_GET['id'];

    // Verifica se o ID é válido
    if (is_numeric($usuario_id)) {
        // Preparar a SQL para reativar o revendedor (restaurando a validade)
        // Aqui você deve definir o valor original da validade (por exemplo, 30 dias)
        $validade_original = 30; // Exemplo de validade original

        $sql = "UPDATE ssh_accounts SET expira = ? WHERE id = ?";
        
        // Preparar a declaração
        if ($stmt = $conn->prepare($sql)) {
            // Vincula os parâmetros: validade e id
            $stmt->bind_param("ii", $validade_original, $usuario_id);

            // Executa a consulta
            if ($stmt->execute()) {
                echo 'success';
            } else {
                echo 'error';
            }

            // Fecha a declaração
            $stmt->close();
        }
    } else {
        // Redireciona com erro se o ID for inválido
        echo 'invalid';
    }
}

// Fecha a conexão com o banco
$conn->close();
?>
