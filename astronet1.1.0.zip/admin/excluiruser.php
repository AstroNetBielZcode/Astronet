<?php
include('../astro/conexao.php'); // Conexão com o banco de dados
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['id'])) {
    $usuario_id = $_POST['id'];

    // Verifica se o ID é válido
    if (is_numeric($usuario_id)) {
        // Comando SQL para excluir o revendedor
        $sql = "DELETE FROM ssh_accounts WHERE id = ?";
        
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("i", $usuario_id); // Vincula o ID

            if ($stmt->execute()) {
                echo 'success'; // Retorna sucesso para o JavaScript
            } else {
                echo 'error'; // Retorna erro
            }

            $stmt->close();
        }
    } else {
        echo 'invalid'; // Retorna ID inválido
    }
}

$conn->close(); // Fecha a conexão
?>
