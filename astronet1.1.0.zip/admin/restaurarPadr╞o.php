<?php
// Remova qualquer saída antes do JSON
ob_clean();
header('Content-Type: application/json');

include('../astro/conexao.php');

$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['reset']) || $data['reset'] !== true) {
    echo json_encode(["status" => "error", "message" => "Requisição inválida"]);
    exit;
}

// Executa a query
$sql = "UPDATE configs SET corfundologo = '' WHERE id = 1";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => "Erro no banco: " . $conn->error]);
}
exit;
?>
