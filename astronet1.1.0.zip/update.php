<?php
error_reporting(0); // Oculta erros do PHP para não interferir no JSON
ini_set('display_errors', 0);
header('Content-Type: application/json');

if (!isset($_GET['url'])) {
    echo json_encode(["success" => false, "message" => "URL não especificada."]);
    exit;
}

$url = $_GET['url'];
$zipFile = "astronet1.1.0.zip";
$extractTo = "./";

function baixarArquivo($url, $destino) {
    $fileContent = file_get_contents($url);
    if ($fileContent === false) {
        return false;
    }
    return file_put_contents($destino, $fileContent);
}

// Baixa o arquivo ZIP
if (!baixarArquivo($url, $zipFile)) {
    echo json_encode(["success" => false, "message" => "Erro ao baixar o arquivo ZIP. Verifique a URL."]);
    exit;
}

// Abrir o arquivo ZIP
$zip = new ZipArchive;
if ($zip->open($zipFile) === TRUE) {
    $zip->extractTo($extractTo);
    $zip->close();
    unlink($zipFile); // Deleta o ZIP após extração

    echo json_encode(["success" => true, "message" => "Atualização concluída com sucesso!"]);
} else {
    echo json_encode(["success" => false, "message" => "Erro ao extrair o arquivo ZIP."]);
}
?>
