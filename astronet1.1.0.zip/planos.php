<?php

error_reporting(0);
session_start();

if (file_exists('astro/conexao.php')) {
    require("astro/conexao.php");
} else {
    header('Location: install.php');
    exit;
}

$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

// Busca configurações do painel
$sql = "SELECT * FROM configs";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $nomepainel = $row["nomepainel"];
        $logo = $row["logo"];
        $icon = $row["icon"];
        $csspersonali = $row["corfundologo"];
    }
}



?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $nomepainel; ?></title>

    <link rel="shortcut icon" href="<?php echo $icon; ?>" type="image/x-icon">

    <!-- Theme -->
    <link rel="stylesheet" href="../app-assets/css/themes/semi-dark-layout.css">
    <link rel="stylesheet" href="../app-assets/css/themes/dark-layout.css">
    <link rel="stylesheet" href="../app-assets/css/components.css">
    <!-- END - Theme -->

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


</head>
<body class="vertical-menu-login"> 
    <div id="rodape" class="rodape-horizontal" style="width: 95.8%;margin-left: 10px;">
        <div class="footer-nav vertical-texts">
            <div class="avatar bg-success mr-1">
                <div class="perfil-perfomace-primary">
                    <div class="perfil-primary">
                        <div class="perfil" id="perfil">
                            <p onclick="conta()">
                                <img src="<?php echo $icon; ?>" alt="icon">
                            </p>
                            <p class="text-plan">
                                Planos do nossos serviços Vpn. <?php echo $nomepainel; ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="content-planos">
        <div class="content-menu">
            <div class="list-plans">
                <div class="plans">

                </div>
            </div>
        </div>
    </div>
</body>
</html>