<?php 
$dbname = 'astronet';
$dbuser = 'root';
$dbpass = '';
$dbhost = 'localhost';
$dbtoken = 'cfdcbf877220b2e2276aa40887955f3a';
?>