<?php
include('../astro/conexao.php');
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

if (isset($_GET['id'])) {
    $revendedor_id = $_GET['id'];

    // Verifica se o ID é válido
    if (is_numeric($revendedor_id)) {
        // Preparar a SQL para reativar o revendedor (restaurando a validade)
        // Aqui você deve definir o valor original da validade (por exemplo, 30 dias)
        $validade_original = 30; // Exemplo de validade original

        $sql = "UPDATE accounts SET validade = ? WHERE id = ?";
        
        // Preparar a declaração
        if ($stmt = $conn->prepare($sql)) {
            // Vincula os parâmetros: validade e id
            $stmt->bind_param("ii", $validade_original, $revendedor_id);

            // Executa a consulta
            if ($stmt->execute()) {
                echo 'success';
            } else {
                echo 'error';
            }

            // Fecha a declaração
            $stmt->close();
        }
    } else {
        // Redireciona com erro se o ID for inválido
        echo 'invalid';
    }
}

// Fecha a conexão com o banco
$conn->close();
?>
