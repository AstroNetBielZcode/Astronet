<?php
include('../astro/conexao.php'); // Conexão com o banco de dados
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

if (isset($_GET['id'])) {
    $revendedor_id = $_GET['id'];

    // Verifica se o ID é válido
    if (is_numeric($revendedor_id)) {
        // Comando SQL para excluir o revendedor
        $sql = "DELETE FROM accounts WHERE id = ?";
        
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("i", $revendedor_id); // Vincula o ID

            if ($stmt->execute()) {
                echo 'success'; // Retorna sucesso para o JavaScript
            } else {
                echo 'error'; // Retorna erro
            }

            $stmt->close();
        }
    } else {
        echo 'invalid'; // Retorna ID inválido
    }
}

$conn->close(); // Fecha a conexão
?>
