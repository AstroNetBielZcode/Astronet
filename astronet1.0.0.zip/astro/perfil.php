<?php

error_reporting(0);

session_start();

require '../astro/conexao.php';

require("../vendor/autoload.php");
use Telegram\Bot\Api;
$dominio = $_SERVER['HTTP_HOST'];
$telegram = new Api('8062935114:AAGNw_4YWiADqJeZin3Sh2onooWJCD3T514');
date_default_timezone_set('America/Sao_Paulo');

$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

if(!isset($_SESSION['login']) and !isset($_SESSION['senha'])){
    session_destroy();
    unset($_SESSION['login']);
    unset($_SESSION['senha']);
    header('location:../index.php');
}


$sql = "SELECT * FROM configs";
$result = $conn -> query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $nomepainel = $row["nomepainel"];
        $logo = $row["logo"];
        $icon = $row["icon"];
        $csspersonali = $row["corfundologo"];
    }
}

$sql = "SELECT * FROM accounts WHERE id = '" . $_SESSION['iduser'] . "'";
$result = $conn -> query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $login = $row["login"];
        $senha = $row["senha"];
    }
}

$mensagem = "";
$tipo = ""; // "success" ou "error"

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (empty($_POST['login']) || empty($_POST['senha'])) {
        $mensagem = "Login e senha não podem estar vazios.";
        $tipo = "error";
    } else {
        $login = $_POST['login'];
        $senha = $_POST['senha'];

        // Query corrigida
        $sql = "UPDATE accounts SET login = ?, senha = ? WHERE id = 1";
        $stmt = $conn->prepare($sql);

        if ($stmt === false) {
            $mensagem = "Falha ao preparar a consulta SQL: " . $conn->error;
            $tipo = "error";
        } else {
            $stmt->bind_param("ss", $login, $senha);
            if ($stmt->execute()) {
                $mensagem = "Perfil atualizado com sucesso!";
                $tipo = "success";
            } else {
                $mensagem = "Erro ao atualizar o perfil: " . $stmt->error;
                $tipo = "error";
            }
            $stmt->close();
        }
    }
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="<?php echo $icon; ?>" type="image/x-icon">
    <title><?php echo $nomepainel; ?> - Painel Administrativo</title>

    <!-- Theme -->
    <link rel="stylesheet" href="../app-assets/css/themes/semi-dark-layout.css">
    <link rel="stylesheet" href="../app-assets/css/themes/dark-layout.css">
    <link rel="stylesheet" href="../app-assets/css/components.css">
    <!-- END - Theme -->
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" />


    <!-- DataTables -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.8/css/dataTables.jqueryui.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdn.datatables.net/2.0.3/js/dataTables.js"></script>
    <script src="https://cdn.datatables.net/2.0.3/js/dataTables.bootstrap5.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">  

    <style>
        <?php echo $csspersonali ?>
    </style>
</head>
<body class="vertical-menu-body bootstrap-color" id="data-value-carregando" style="overflow-y: hidden;">
    <div id="rodape" class="rodape-horizontal">
        <div class="footer-nav vertical-texts">
            <button class="btn-open" onclick="toggleSidebar()" id="open-btn"><i class="fa-solid fa-bars"></i></button>
            <div class="areaclient">
                <div class="bar-horizontal"></div>
                <p>Area do Painel</p>
                <svg class="svgs mobile-size" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            </div>
            <button class="btn-primary-sucess m6-0" onclick="criarteste()"><svg class="svgs" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-plus"><circle cx="12" cy="12" r="10"/><path d="M8 12h8"/><path d="M12 8v8"/></svg> Teste Rapido</button>
            <div class="areaclient">
                <div class="bar-horizontal"></div>
                <p>Area do Client</p>
                <svg class="svgs mobile-size" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            </div>
            <button class="btn-primary-sucess m6-0" id="openModal"><svg class="svgs" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-headset"><path d="M3 11h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-5Zm0 0a9 9 0 1 1 18 0m0 0v5a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3Z"/><path d="M21 16v2a4 4 0 0 1-4 4h-5"/></svg> Suporte</button>
            <button class="btn-primary-sucess m6-0" id="openModal"><svg class="svgs" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-book-marked"><path d="M10 2v8l3-3 3 3V2"/><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20"/></svg> Documentario Api</button>
            <script>
                function criarusuario() {
                    window.location.href = 'criarteste.php';
                }
                function conta() {
                    window.location.href = 'perfil.php';
                }
            </script>
            <div class="avatar bg-success mr-1">
                <div class="perfil-perfomace-primary">
                    <div class="perfil-primary">
                        <div class="perfil" id="perfil">
                            <p onclick="conta()">
                                <img src="<?php echo $icon; ?>" alt="icon">
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Content Menu Create/list -->
    <div class="content-dialog" style="width: 650px;">
        <div class="element-dialog"> 
            <div class="dialog">
                <div class="form">
                    <div class="h4">
                        <h4 for="categoria">Seu Perfil</h4>
                    </div>
                    <form id="createForm" method="post">
                        <div class="form-group-create">
                            <label for="login">login: </label>
                            <input type="text" name="login" id="login" value="<?php echo $login; ?>">

                            <label for="senha">Senha: </label>
                            <input type="text" name="senha" id="senha" value="<?php echo $senha; ?>">
                        </div>
                            <div class="group-inputs">
                                <button type="submit" class="btn-scs-create" id="btn-criarcat">Salvar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        // Variáveis PHP para JS
        var mensagem = "<?php echo $mensagem; ?>";
        var tipo = "<?php echo $tipo; ?>";

        // Exibe o SweetAlert2 apenas se houver uma mensagem
        if (mensagem !== "") {
            Swal.fire({
                icon: tipo,
                title: mensagem,
                color: "#ffffff",
                background: "#1e1e2f",
                showConfirmButton: tipo === "error"
            });
        }
    </script>
    <style>
        body {
            overflow: auto !important;
        }

        .form-group-create input {
            width: 98%;
        }

        @media screen and (max-width: 768px) {
            .rodape-horizontal {
                position: relative;
                top: 40px;
                margin-top: -150px;
                width: 90.5%;
                margin-left: 5px !important;
            }
            .content-dialog {
                width: auto;
                min-height: 310px;
                margin-top: 120px;
                border-radius: 12px;
                position: relative; 
                padding: 25px !important;
            }

            .element-dialog {
                margin-left: -2px;
                width: 100%;
            }
        }
    </style>

    <div class="sidebar">
        <img onclick="voltar()" src="<?php echo $logo; ?>" alt="logo">
        <script>
            function voltar() {
                    window.location.href = '../home.php';
            }
        </script>
        <button class="close-btn" onclick="toggleSidebar()">×</button>
        <ul>
            <li class="inicio"><a href="../home.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-house"><path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>Início</a></li>
            <li class="has-submenu">
                <a><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-users"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>Usuarios<svg class="arrow"xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-right"><path d="m9 18 6-6-6-6"/></svg></a>
                <ul class="submenu">
                    <li><a href="criarusuario.php">Criar Usuário</a></li>
                    <li><a href="criarteste.php">Criar Teste</a></li>
                    <li><a href="listausers.php">Listar Usuários</a></li>
                    <li><a href="listaexpirados.php">Listar Expirados</a></li>
                    <li><a href="listaonlines.php">Listar Onlines</a></li>
                </ul>
            </li>
            <li class="has-submenu">
                <a><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-users-round"><path d="M18 21a8 8 0 0 0-16 0"/><circle cx="10" cy="8" r="5"/><path d="M22 20c0-3.37-2-6.5-4-8a5 5 0 0 0-.45-8.3"/></svg>Revendedores<svg class="arrow"xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-right"><path d="m9 18 6-6-6-6"/></svg></a>
                <ul class="submenu">
                    <li><a href="criarreven.php">Criar Revenda</a></li>
                    <li><a href="listarreven.php">Listar Revendas</a></li>
                </ul>
            </li>
            <li>
                <a href="perfil.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user-pen"><path d="M11.5 15H7a4 4 0 0 0-4 4v2"/><path d="M21.378 16.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z"/><circle cx="10" cy="7" r="4"/></svg>Perfil</a>
            </li>
            <li class="has-submenu">
                <a><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-credit-card"><rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/></svg>Pagamentos<svg class="arrow"xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-right"><path d="m9 18 6-6-6-6"/></svg></a>
                <ul class="submenu">
                    <li><a href="configPag.php">Configurar</a></li>
                    <li><a href="listarPlanos.php">Planos</a></li>
                    <li><a href="cupom.php">Cupom</a></li>
                    <li><a href="vendas.php">Vendas</a></li>
                </ul>
            </li>
            <li>
                <a href="https://t.me/astronetupdates1"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-send"><path d="M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z"/><path d="m21.854 2.147-10.94 10.939"/></svg>Suporte Telegram</a>
            </li>
            <li>
                <a href="logs.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-door-open"><path d="M13 4h3a2 2 0 0 1 2 2v14"/><path d="M2 20h3"/><path d="M13 20h9"/><path d="M10 12v.01"/><path d="M13 4.562v16.157a1 1 0 0 1-1.242.97L5 20V5.562a2 2 0 0 1 1.515-1.94l4-1A2 2 0 0 1 13 4.561Z"/></svg>Logs</a>
            </li>
            <li><a href="../logout.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-log-out"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>Sair</a></li>
        </ul>
    </div>
    <footer>
        <p></p>
    </footer>
    <script>
        document.querySelectorAll('.has-submenu > a').forEach(function(menuLink) {
            menuLink.addEventListener('click', function(e) {
                e.preventDefault();
                var submenu = this.nextElementSibling;
                var isVisible = submenu.classList.contains('show');
                document.querySelectorAll('.submenu').forEach(function(sub) {
                    sub.classList.remove('show');
                });
                if (!isVisible) {
                    submenu.classList.add('show');
                }
            });
        });
        document.querySelectorAll('.submenu .close-btn').forEach(function(closeBtn) {
            closeBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                this.parentElement.classList.remove('show');
            });
        });
        
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            const mainContent = document.getElementById('main-content');
            
            if (sidebar.style.transform === 'translateX(0%)') {
                sidebar.style.transform = 'translateX(-100%)';
                mainContent.style.marginLeft = '0';
            } else {
                sidebar.style.transform = 'translateX(0%)';
                mainContent.style.marginLeft = '250px';
            }
        }

    </script>
</body>
</html>