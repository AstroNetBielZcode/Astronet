<?php

error_reporting(0);


session_start();

require 'astro/conexao.php';

require("vendor/autoload.php");
use Telegram\Bot\Api;
$dominio = $_SERVER['HTTP_HOST'];
$telegram = new Api('8062935114:AAGNw_4YWiADqJeZin3Sh2onooWJCD3T514');
date_default_timezone_set('America/Sao_Paulo');

try {
    $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
} catch (mysqli_sql_exception $e) {
    header('Location: index.php');
    exit;
}

if (!isset($_SESSION['login'])) {
    header('Location: index.php');
    exit();
}


$sql = "SELECT * FROM configs";
$result = $conn -> query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $nomepainel = $row["nomepainel"];
        $logo = $row["logo"];
        $icon = $row["icon"];
        $csspersonali = $row["corfundologo"];
    }
}


$sql6 = "SELECT COUNT(*) FROM accounts WHERE byid = '".$_SESSION['iduser']."'";  
$result5 = mysqli_query($conn, $sql6);

if ($result5) {
    $row = mysqli_fetch_row($result5);
    $totalrevendaglobal = $row[0];  
}

$tokenvb = "SELECT * FROM accounts WHERE id = '".$_SESSION['iduser']."'";
$resultvb = mysqli_query($conn, $tokenvb);
$rowvb = mysqli_fetch_assoc($resultvb);
$tokenvenda = $rowvb['tokenvenda'];


date_default_timezone_set('America/Sao_Paulo'); 

$hora = date('H');

if ($hora >= 6 && $hora < 12) {
    $periodo = 'Bom dia';
} elseif ($hora >= 12 && $hora < 18) {
    $periodo = 'Boa tarde';
} elseif ($hora >= 18 && $hora < 24) {
    $periodo = 'Boa noite';
} else {
    $periodo = 'Boa madrugada';
}

//consulta usuarios expirados
date_default_timezone_set('America/Sao_Paulo');
$data = date('Y-m-d H:i:s');
$slq5 = "SELECT * FROM ssh_accounts WHERE byid = '".$_SESSION['iduser']."' and expira < '$data'";
$result5 = mysqli_query($conn, $slq5);
$totalvencidos = mysqli_num_rows($result5);

$sql3 = "SELECT * FROM ssh_accounts WHERE byid = '".$_SESSION['iduser']."'";
//contar quantos ssh tem
$result3 = mysqli_query($conn, $sql3);
$totalusuarios = mysqli_num_rows($result3); 

$sql8 = "SELECT * FROM accounts WHERE byid = '".$_SESSION['iduser']."'";
//contar quantos revedendores tem
$result7 = mysqli_query($conn, $sql8);
$totalrevenda = mysqli_num_rows($result7); 

$slq7 = "SELECT sum(valor) AS valor  FROM pagamentos where byid='".$_SESSION['iduser']."' and status='Aprovado'";
$result6 = mysqli_query($conn, $slq7);
$row3 = mysqli_fetch_assoc($result6);
$totalvendido = $row3['valor'];
$totalvendido = number_format($totalvendido, 2, ',', '.');

$sql16 = "SELECT * FROM ssh_accounts WHERE status = 'Online' and byid = '".$_SESSION['iduser']."'";
$result16 = mysqli_query($conn, $sql16);
$totalonline = mysqli_num_rows($result16);
$seusonlines = $totalonline;


$sql190 = "SELECT limite FROM accounts WHERE id = '".$_SESSION['iduser']."'";
$result = mysqli_query($conn, $sql190);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $limite = $row['limite'];
}

$sql = "SELECT validade FROM accounts WHERE id = '".$_SESSION['iduser']."'";
$result = mysqli_query($conn, $sql);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $validade = $row['validade'];
}

// Verifique se há revendedores antes de executar a consulta
if (!empty($revendedoresIDs)) {
    // Consulta para buscar todos os online dos revendedores
    $sqlOnlineRevendedores = "SELECT * FROM ssh_accounts WHERE status = 'Online' AND byid IN (".implode(",", $revendedoresIDs).")";
    $resultOnlineRevendedores = mysqli_query($conn, $sqlOnlineRevendedores);

    // Obtenha o número total de contas online dos revendedores
    $totalOnlineRevendedores = mysqli_num_rows($resultOnlineRevendedores);
} else {
    $totalOnlineRevendedores = 0; // Define como zero se não houver revendedores
}

$sql = "SELECT validade, ultima_verificacao FROM accounts WHERE id = '".$_SESSION['iduser']."'";
$result = mysqli_query($conn, $sql);

$mensagem = "";  // Inicializando a variável mensagem

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $validade = (int)$row['validade']; // Converte para número inteiro
    $ultima_verificacao = $row['ultima_verificacao'];  // Corrigido de 'validade' para 'ultima_verificacao'

    // Obtém a data atual
    $data_atual = date('Y-m-d');

    // Se a última verificação não for hoje, diminui a validade
    if ($ultima_verificacao !== $data_atual) {
        if ($validade > 0) {
            $validade--; // Diminui 1 dia

            // Atualiza o banco de dados com a nova validade e a data da última verificação
            $sql_update = "UPDATE accounts SET validade = '$validade', ultima_verificacao = '$data_atual' WHERE id = '".$_SESSION['iduser']."'";
            mysqli_query($conn, $sql_update);
        }
    }

    // Verificando a validade e exibindo a mensagem
    if ($validade <= 0) {
        // Se a validade for 0 ou menor, exibe a mensagem de suspensão usando SweetAlert
        $mensagem = "<script>
            Swal.fire({
                icon: 'error',
                title: '👮‍♂️ O seu painel foi suspenso!',
                html: '🚫A validade do seu painel expirou🚫.<br><br>💠 Contate um suporte: <a href=\"https://t.me/astronetupdates1\" target=\"_blank\" style=\"color: white;\">https://t.me/astronetupdates1</a>',
                background: '#222',
                color: '#fff',
                confirmButtonColor: '#007bff',
                allowOutsideClick: false,
                allowEscapeKey: false,
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'logout.php';
                }
            });
        </script>";

    } else if ($validade <= 7) {
        // Se a validade estiver perto de zero (exemplo: 7 dias ou menos), exibe os dias restantes usando SweetAlert
        $mensagem = "<script>
            Swal.fire({
                icon: 'warning',
                title: 'Seu painel expirará em " . $validade . " dias!',
                text: 'Por favor, renove o quanto antes!',
                background: '#222',
                color: '#fff',
                confirmButtonColor: '#007bff',
            });
        </script>";
    } else {
        // Caso contrário, exibe uma mensagem de validade em dia
        $mensagem = "<script>
            Swal.fire({
                icon: 'success',
                title: 'Seu painel está ativo!',
                text: 'Você tem mais " . $validade . " dias restantes.',
                background: '#222',
                color: '#fff',
                confirmButtonColor: '#007bff',
            });
        </script>";
    }    
}
?>


<?php

if (isset($_POST['voltaradmin']) && isset($_SESSION['admin564154156'])) {
    $sqladmin = "SELECT * FROM accounts WHERE id = '1'";
    $resultadmin = $conn->query($sqladmin);
    $rowadmin = $resultadmin->fetch_assoc();
       //destrói as sessões existentes
       $_SESSION['login'] = $rowadmin['login'];
       $_SESSION['senha'] = $rowadmin['senha'];
       $_SESSION['iduser'] = $rowadmin['id']; 
       echo "<script>window.location.href='admin/home.php';</script>";
} 

?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="<?php echo $icon; ?>" type="image/x-icon">
    <title><?php echo $nomepainel; ?> - Painel Administrativo</title>

    <!-- Theme -->
    <link rel="stylesheet" href="app-assets/css/themes/semi-dark-layout.css">
    <link rel="stylesheet" href="app-assets/css/themes/dark-layout.css">
    <link rel="stylesheet" href="app-assets/css/components.css">
    <!-- END - Theme -->

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="app-assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />
    <link rel="stylesheet" href="app-assets/vendor/libs/apex-charts/apex-charts.css" />

    <!-- Adicionar SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" />


    <!-- DataTables -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.8/css/dataTables.jqueryui.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdn.datatables.net/2.0.3/js/dataTables.js"></script>
    <script src="https://cdn.datatables.net/2.0.3/js/dataTables.bootstrap5.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Swal.fire -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@5/dark.css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>

    <!-- END - SweetAlert2 -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">  

    <style>
        <?php echo $csspersonali ?>
    </style>
</head>
<body class="vertical-menu-body bootstrap-color" id="data-value-carregando">

    <!-- NOTIFICAÇÂO REVENDEDOR -->
    <?php

    if (!isset($_SESSION['notification_shown'])) {
        $_SESSION['notification_shown'] = true; // Marca que a notificação foi exibida
    ?>
        <script>
        Swal.fire({
            title: 'Olá 😉 Bem Vindo',
            html: `
                📢 Link de Suporte
                <br>
                <a href="https://t.me/astronetupdates1" target="_blank" style="color: #3085d6;">Suporte</a>
            `,
            icon: null,  
            confirmButtonText: 'OK',
            showCancelButton: false,
            reverseButtons: true,  
        })
    </script>

    <?php
    }
    ?>
    <?php echo $mensagem; ?>

    <div id="rodape" class="rodape-horizontal">
        <div class="footer-nav vertical-texts">
            <button class="btn-open" id="open-btn"><i class="fa-solid fa-bars"></i></button>
            <button class="btn-primary-sucess m6-0" onclick="criarteste()"><svg class="svgs" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-plus"><circle cx="12" cy="12" r="10"/><path d="M8 12h8"/><path d="M12 8v8"/></svg> Teste Rapido</button>
            <script>
                function criarusuario() {
                    window.location.href = 'criarteste.php';
                }
            </script>
            <div class="avatar bg-success mr-1">
                <div class="perfil-perfomace-primary">
                    <div class="perfil-primary">
                        <div class="perfil" id="perfil">
                            <p id="nav-bar" onclick="navbar()">
                                <img src="<?php echo $icon; ?>" alt="icon">
                            </p>
                            <script>
                                function navbar() {
                                    let elemento = document.getElementById("navbar-account");
                                    if (elemento.style.display === "none" || elemento.style.display === "") {
                                        elemento.style.display = "block";
                                    } else {
                                        elemento.style.display = "none";
                                    }
                                }
                            </script>
                            <div class="navbar-account" id="navbar-account">
                                <p id="nav-bar">
                                    <img src="<?php echo $icon; ?>" alt="icon">
                                    <span class="text-perfil">Olá <?php echo $_SESSION['login']; ?></span>
                                </p>
                                <?php if (isset($_SESSION['admin564154156'])) { ?>
                                    <form method="post" action="home.php">
                                    <button type="submit" name="voltaradmin" class="back-button btn btn-outline-primary">
                                        Voltar para Painel
                                    </button>
                                    </form>
                                <?php } ?>
                                <a href="astro/perfil.php">Perfil</a>
                                <br>
                                <a href="../logout.php">Sair</a>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="btn-open">
        <div class="btn-primary">
            <div id="main-content">
                <button class="open-btn" onclick="toggleSidebar()"></button>
            </div>
        </div>
    </div>
    <div class="text">
        <div class="text-alert">
            <p><span><?php echo $periodo; ?></span><span class="login-name" style="margin-left: 5px;"><?php echo $_SESSION['login']; ?>🎉</span></p>
            <p class="limite">Limite: <?php echo $limite; ?></p>
        </div>
    </div>
    <div class="validity">
        <p><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-clock"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>Validade: <?php echo $validade; ?><p class="text-vali"></p></p>
    </div>
    <div class="carder-menu-r8">
        <div class="vertical-menu-r8">
            <div class="main-menu">
                <div class="stat-items">
                    <div class="items">
                        <div class="row">
                            <i class='fas fa-user-friends fa-2x text-primary'></i>
                            <p class="text-stat">Meus Onlines</p>
                            <span><?php echo $seusonlines; ?></span>
                        </div>
                    </div>
                </div>
                <div class="stat-items">
                    <div class="items">
                        <div class="row">
                            <i class='fas fa-globe fa-2x text-success'></i>
                            <p class="text-stat">Revendedores Onlines</p>
                            <span><?php echo $totalOnlineRevendedores; ?></span>
                        </div>
                    </div>
                </div>  
                <div class="stat-items">
                    <div class="items">
                        <div class="row">
                            <i class='fas fa-store fa-2x text-warning1'></i>
                            <p class="text-stat">Meus Revendedores</p>
                            <span><?php echo $totalrevenda; ?></span>
                        </div>
                    </div>
                </div>
                <div class="stat-items">
                    <div class="items">
                        <div class="row">
                        <i class='fas fa-people-arrows fa-2x text-danger'></i>  
                            <p class="text-stat">Revendedores Globais</p>
                            <span><?php echo $totalrevendaglobal; ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="main-menu">
                <div class="stat-items">
                    <div class="items">
                        <div class="row">
                            <i class='fas fa-user fa-2x text-info'></i>
                            <p class="text-stat">Meus Usuários</p>
                            <span><?php echo $totalusuarios; ?></span>
                        </div>
                    </div>
                </div>
                <div class="stat-items">
                    <div class="items">
                        <div class="row">
                            <i class='fas fa-users fa-2x text-secondary'></i>
                            <p class="text-stat">Total Onlines</p>
                            <span><?php echo $totalusuarios; ?></span>
                        </div>
                    </div>
                </div>
                <div class="stat-items">
                    <div class="items">
                        <div class="row">
                            <i class='fas fa-check-circle fa-2x text-success'></i>
                            <p class="text-stat">Pagamentos Sucedidos</p>
                            <span><?php echo $totalvendido; ?></span>
                        </div>
                    </div>
                </div>
                <div class="stat-items">
                    <div class="items">
                        <div class="row">
                            <i class='fa-regular fa-clock fa-2x text-primary'></i>
                            <p class="text-stat">Total Vencidos</p>
                            <span><?php echo $totalvencidos; ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        function gerar_token()
              {
                  $tokenvenda = md5(uniqid(rand(), true));
                  return $tokenvenda;
              }
    </script>
    <div class="main-carder">
        <div class="carder">
            <table class="links">
                <div class="alert-text1">
                    <p>Links Utilizaveis</p>
                </div>
                <div class="card-content">
                    <div class="card-body">
                        <p class="text-warning">
                            ⚠️ Não esqueça!! <span class="text-primary">"Gerar novo link"</span> se for a primeira vez acessando o painel.
                        </p>

                             <!-- Cron de backup -->
                            <div class="mb-4">
                                <div class="divider-text text-primary">Cron de backup</div>
                                <div class="input-group">
                                    <input type="text" class="form-control" value="<?php echo "https://$dominio/backup.php"; ?>" readonly>
                                    <button class="btn btn-primary" type="button" onclick="copyToClipboard('https://<?php echo $dominio; ?>/backup.php')">Copiar</button>
                                </div>
                            </div>

                            <!-- Links de acesso -->
                            <div class="mb-4">
                                <div class="divider-text text-primary">Vendas Painel Revenda</div>
                                <div class="input-group">
                                    <input type="text" class="form-control" value="<?php echo "https://$dominio/revenda.php?token="?><?php echo $tokenvenda; ?>" readonly>
                                    <button class="btn btn-primary" type="button" onclick="copyToClipboard('https://<?php echo $dominio; ?>/revenda.php?token=')">Copiar</button>
                                </div>
                            </div>

                            <div class="mb-4">
                                <div class="divider-text text-primary">Vendas Usuário Final</div>
                                <div class="input-group">
                                    <input type="text" class="form-control" value="<?php echo "https://$dominio/comprar.php?token="?><?php echo $tokenvenda; ?>" readonly>
                                    <button class="btn btn-primary" type="button" onclick="copyToClipboard('https://<?php echo $dominio; ?>/comprar.php?token=')">Copiar</button>
                                </div>
                            </div>

                            <div class="mb-4">
                                <div class="divider-text text-primary">Link Teste Automático</div>
                                <div class="input-group">
                                    <input type="text" class="form-control" value="<?php echo "https://$dominio/criarteste.php?token="?><?php echo $tokenvenda; ?>" readonly>
                                    <button class="btn btn-primary" type="button" onclick="copyToClipboard('https://<?php echo $dominio; ?>/criarteste.php?token=')">Copiar</button>
                                </div>
                            </div>

                        <!-- Botão de Gerar Novo Link -->
                        <form action="home.php" method="post">
                            <div class="text-center my-4">
                                <button class="btn-grtl btn-success" id="gerarlink" type="submit" name="gerarlink" id="gerarlink">Gerar Novo Link</button>
                            </div>
                        </form>
                        <?php
                            if(isset($_POST['gerarlink'])){
                                $codigo = rand(100000000000,999999999999);
                                $id = $_SESSION['iduser'];
                                $sql = "UPDATE accounts SET tokenvenda = '$codigo' WHERE id = '$id'";
                                $result = $conn -> query($sql);
                                echo "<meta http-equiv='refresh' content='0'>";
                            }
                        ?>

                        </form>
                        <script>
                            function copyToClipboard(text) {
                            navigator.clipboard.writeText(text).then(() => {
                                Swal.fire({
                                    title: 'Sucesso!',
                                    text: 'Link copiado para a área de transferência!',
                                    icon: 'success',
                                    confirmButtonText: 'OK'
                                });
                            }).catch(err => {
                                Swal.fire({
                                    title: 'Ops...',
                                    text: 'Erro ao copiar o link. Tente novamente.',
                                    icon: 'error',
                                    confirmButtonText: 'OK'
                                });
                            });
                            }
                        </script>
                    </div>
                </div>
            </table>
        </div>
    </div>  
    </div>
    <div class="sidebar">
        <img onclick="voltar()" src="<?php echo $logo; ?>" alt="logo">
        <script>
            function voltar() {
                    window.location.href = 'home.php';
            }
        </script>
        <button class="close-btn" onclick="toggleSidebar()">×</button>
        <ul>
            <li class="inicio"><a href="home.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-house"><path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>Início</a></li>
            <li class="has-submenu">
                <a><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-users"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>Usuarios<svg class="arrow"xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-right"><path d="m9 18 6-6-6-6"/></svg></a>
                <ul class="submenu">
                    <li><a href="astro/criarusuario.php">Criar Usuário</a></li>
                    <li><a href="astro/criarteste.php">Criar Teste</a></li>
                    <li><a href="astro/listausers.php">Listar Usuários</a></li>
                    <li><a href="astro/listaexpirados.php">Listar Expirados</a></li>
                    <li><a href="astro/listaonlines.php">Listar Onlines</a></li>
                </ul>
            </li>
            <li class="has-submenu">
                <a><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-users-round"><path d="M18 21a8 8 0 0 0-16 0"/><circle cx="10" cy="8" r="5"/><path d="M22 20c0-3.37-2-6.5-4-8a5 5 0 0 0-.45-8.3"/></svg>Revendedores<svg class="arrow"xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-right"><path d="m9 18 6-6-6-6"/></svg></a>
                <ul class="submenu">
                    <li><a href="astro/criarreven.php">Criar Revenda</a></li>
                    <li><a href="astro/listarreven.php">Listar Revendas</a></li>
                </ul>
            </li>
            <li>
                <a href="perfil.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user-pen"><path d="M11.5 15H7a4 4 0 0 0-4 4v2"/><path d="M21.378 16.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z"/><circle cx="10" cy="7" r="4"/></svg>Perfil</a>
            </li>
            <li class="has-submenu">
                <a><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-credit-card"><rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/></svg>Pagamentos<svg class="arrow"xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-right"><path d="m9 18 6-6-6-6"/></svg></a>
                <ul class="submenu">
                    <li><a href="astro/configPag.php">Configurar</a></li>
                    <li><a href="astro/listarPlanos.php">Planos</a></li>
                    <li><a href="astro/cupom.php">Cupom</a></li>
                    <li><a href="astro/vendas.php">Vendas</a></li>
                </ul>
            </li>
            <li>
                <a href="https://t.me/astronetupdates1"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-send"><path d="M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z"/><path d="m21.854 2.147-10.94 10.939"/></svg>Suporte Telegram</a>
            </li>
            <li>
                <a href="astro/logs.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-door-open"><path d="M13 4h3a2 2 0 0 1 2 2v14"/><path d="M2 20h3"/><path d="M13 20h9"/><path d="M10 12v.01"/><path d="M13 4.562v16.157a1 1 0 0 1-1.242.97L5 20V5.562a2 2 0 0 1 1.515-1.94l4-1A2 2 0 0 1 13 4.561Z"/></svg>Logs</a>
            </li>
            <li><a href="../logout.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-log-out"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>Sair</a></li>
        </ul>
    </div>
    <footer>
        <p></p>
    </footer>
    <script>
        document.querySelectorAll('.has-submenu > a').forEach(function(menuLink) {
            menuLink.addEventListener('click', function(e) {
                e.preventDefault();
                var submenu = this.nextElementSibling;
                var isVisible = submenu.classList.contains('show');
                document.querySelectorAll('.submenu').forEach(function(sub) {
                    sub.classList.remove('show');
                });
                if (!isVisible) {
                    submenu.classList.add('show');
                }
            });
        });
        document.querySelectorAll('.submenu .close-btn').forEach(function(closeBtn) {
            closeBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                this.parentElement.classList.remove('show');
            });
        });
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            const mainContent = document.getElementById('main-content');
            
            if (sidebar.style.transform === 'translateX(0%)') {
                sidebar.style.transform = 'translateX(-100%)';
                mainContent.style.marginLeft = '0';
            } else {
                sidebar.style.transform = 'translateX(0%)';
                mainContent.style.marginLeft = '250px';
            }
        }

    </script>
</body>
</html>