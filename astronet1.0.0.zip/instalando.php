<?php
session_start();
include('astro/conexao.php');

if(file_exists('astro/conexao.php')) {
}else {
  header('Location: index.php');
  exit;
}



try {
  $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
  if (!$conn) {
      throw new Exception("Erro ao conectar ao banco de dados: " . mysqli_connect_error());
  }
} catch (Exception $e) {
  echo "<script>window.location.href = 'install.php';</script>";
  exit;
}

//criar tabelas
$sql = "CREATE TABLE `accounts` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `categoria` INT(11) NOT NULL,
        `nome` varchar(255) DEFAULT NULL,
        `contato` varchar(255) DEFAULT NULL,
        `whatsapp` VARCHAR(255) NOT NULL,
        `login` varchar(50) NOT NULL DEFAULT '0',
        `token` varchar(330) NOT NULL DEFAULT '0',
        `mb` varchar(50) NOT NULL DEFAULT '0',
        `senha` varchar(50) NOT NULL DEFAULT '0',
        `byid` varchar(50) NOT NULL DEFAULT '0',
        `mainid` varchar(50) NOT NULL DEFAULT '0',
        `accesstoken` text DEFAULT NULL,
        `valorusuario` varchar(50) DEFAULT NULL,
        `valorrevenda` varchar(50) DEFAULT NULL,
        `idtelegram` text DEFAULT NULL,
        `tokenvenda` varchar(255) DEFAULT NULL,
        `catpadrao` varchar(255) DEFAULT NULL,
        `valor` DECIMAL(10,2) NOT NULL DEFAULT 25.00,
        `limite` INT(11) NOT NULL DEFAULT 10,
        `validade` INT(11) NOT NULL DEFAULT 30,
        `modo` ENUM('validade', 'creditos') NOT NULL DEFAULT 'validade',
        `criarsub` ENUM('sim', 'nao') NOT NULL DEFAULT 'nao',
        `puxartexto` ENUM('sim', 'nao') NOT NULL DEFAULT 'nao',
        `renovacao_periodo` INT(11) NOT NULL DEFAULT 30,
        `tokentelegram` varchar(300) NOT NULL DEFAULT 30,
        PRIMARY KEY (`id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;";

$result = mysqli_query($conn, $sql);
if (!$result) {
    echo "<script>alert('Erro ao criar tabela accounts');</script>";
    exit;
}
//adicionar a conta admin
$sql2 = "INSERT INTO `accounts` (`id`, `nome`, `contato`, `login`, `token`, `mb`, `senha`, `byid`, `mainid`, `accesstoken`, `valorusuario`, `valorrevenda`) VALUES
(1, 'admin', 'admin', 'admin', 'admin', '60', '12345', '0', '0', NULL, '0', '0');";
$result2 = mysqli_query($conn, $sql2);

$sql44 = "CREATE TABLE IF NOT EXISTS `astrodeviceid` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `nome_user` varchar(255) DEFAULT NULL,
    `deviceid` varchar(255) DEFAULT NULL,
    `byid` int(11) DEFAULT NULL,
    PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;";
$result44 = mysqli_query($conn, $sql44);

$sql4 = "CREATE TABLE IF NOT EXISTS `categorias` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `subid` int(11) DEFAULT NULL,
    `nome` varchar(150) DEFAULT NULL,
    PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;";
    $result4 = mysqli_query($conn, $sql4);

$sql55 = "CREATE TABLE IF NOT EXISTS `configs` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `nomepainel` text DEFAULT NULL,
  `logo` text DEFAULT NULL,
  `icon` text DEFAULT NULL,
  `corborder` text DEFAULT NULL,
  `corletranav` text DEFAULT NULL,
  `deviceativo` text DEFAULT NULL,
  `imglogin` text DEFAULT NULL,
  `corbarranav` text DEFAULT NULL,
  `corfundologo` text DEFAULT NULL,
  `corcard` text DEFAULT NULL,
  `cortextcard` text DEFAULT NULL,
  `cornavsuperior` text DEFAULT NULL,
  `minimocompra` text DEFAULT NULL,
  `tempodeteste` varchar(50) DEFAULT NULL,
  `catpadrao` varchar(50) DEFAULT NULL,
  `valor` varchar(255) DEFAULT NULL,
  `textoteste` text NOT NULL,
  `textousuario` text NOT NULL,
  `textorevendedor` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";

$result55 = mysqli_query($conn, $sql55);  

$sql22 = "INSERT INTO `configs` (`id`, `nomepainel`, `logo`, `icon`, `textoteste`, `textousuario`, `textorevendedor`) 
  VALUES 
  (1, 'ASTRONET PANEL', 'https://i.postimg.cc/hPYnpGfd/IMG-20240620-180411-488-x-113-pixel.png', 'https://i.postimg.cc/5NSfrRmB/1718932918842.png', 
  '🎉 Teste criado com sucesso! 🎉<br><br>🎯 Login: {login}<br><br>🔑 Senha: {senha}<br><br>📌 Limite: {limite} usuários<br><br>📆 tempo: {validade} minutos<br><br>💰 Valor: {valor}<br><br>📢 Para renovar, acesse o link abaixo:{site}?login={login}&senha={senha}', 
  '🎉 Usuario criado com sucesso! 🎉<br><br>🎯 Login: {login}<br><br>🔑 Senha: {senha}<br><br>📌 Limite: {limite} usuários<br><br>📆 Validade: {validade}<br><br>📆 Dias restantes: {dias}<br><br>💰 Valor: {valor}<br><br>📢 Para renovar, acesse o link abaixo:{site}?login={login}&senha={senha}', 
  '🎉 Revenda criado com sucesso! 🎉<br><br>🎯 Login: {login}<br><br>🔑 Senha: {senha}<br><br>📌 Limite: {limite} usuários<br><br>📆 Validade: {validade}<br><br>📆 Dias restantes: {dias}<br><br>💰 Valor: {valor}<br><br>📢 Site de gerenciamento:🌐 {site}');";
$result22 = mysqli_query($conn, $sql22);

$sql45 = "CREATE TABLE IF NOT EXISTS `cupons` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(30) NOT NULL,
  `cupom` varchar(50) NOT NULL,
  `desconto` varchar(50) NOT NULL,
  `usado` varchar(50) NOT NULL,
  `byid` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
";
$result45 = mysqli_query($conn, $sql45);

$sql5 = "CREATE TABLE IF NOT EXISTS `logs` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `userid` int(11) DEFAULT 0,
    `texto` text DEFAULT NULL,
    `validade` text DEFAULT NULL,
    `revenda` text DEFAULT NULL,
    `byid` text DEFAULT NULL,
    PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;";
    $result5 = mysqli_query($conn, $sql5);

$sql98 = "CREATE TABLE IF NOT EXISTS `onlines` (
    `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
    `usuario` text NOT NULL,
    `quantidade` text NOT NULL,
    PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
    $result98 = mysqli_query($conn, $sql98);

$sql6 = "CREATE TABLE IF NOT EXISTS `pagamentos` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `idpagamento` varchar(50) DEFAULT NULL,
    `valor` varchar(50) DEFAULT NULL,
    `texto` text DEFAULT NULL,
    `iduser` varchar(50) DEFAULT NULL,
    `data` text DEFAULT NULL,
    `status` text DEFAULT NULL,
    `login` text DEFAULT NULL,
    `byid` varchar(50) DEFAULT NULL,
    `access_token` text DEFAULT NULL,
    `tipo` text DEFAULT NULL,
    `addlimite` int(11) DEFAULT NULL,
    PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
    $result6 = mysqli_query($conn, $sql6);

$sql7 = "CREATE TABLE IF NOT EXISTS `servidores` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `subid` int(11) NOT NULL DEFAULT 0,
    `nome` varchar(150) NOT NULL DEFAULT '0',
    `porta` int(11) NOT NULL DEFAULT 0,
    `usuario` varchar(150) NOT NULL DEFAULT '0',
    `senha` varchar(150) NOT NULL DEFAULT '0',
    `ip` varchar(150) NOT NULL DEFAULT '0',
    `onlines` varchar(150) NOT NULL DEFAULT '0',
    `lastview` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
    PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;";
    $result7 = mysqli_query($conn, $sql7);

$sql32 = "CREATE TABLE IF NOT EXISTS `userlimiter` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `nome_user` varchar(255) DEFAULT NULL,
    `limiter` varchar(255) DEFAULT NULL,
    PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;";
    $result32 = mysqli_query($conn, $sql32);

$sql8 = "CREATE TABLE IF NOT EXISTS `ssh_accounts` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `byid` int(11) NOT NULL DEFAULT 0,
    `categoriaid` int(11) NOT NULL DEFAULT 0,
    `limite` int(11) NOT NULL DEFAULT 0,
    `bycredit` int(11) NOT NULL DEFAULT 0,
    `login` varchar(50) NOT NULL DEFAULT '0',
    `senha` varchar(50) NOT NULL DEFAULT '0',
    `whatsapp` varchar(255) NOT NULL DEFAULT '0',
    `valor` varchar(255) NOT NULL DEFAULT '0',
    `mainid` text NOT NULL,
    `expira` text DEFAULT NULL,
    `lastview` text DEFAULT NULL,
    `status` text DEFAULT NULL,
    PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;";
  $result51 = mysqli_query($conn, $sql8);
$create = "CREATE TABLE `bot` (
    `id` int(6) UNSIGNED NOT NULL,
    `app` text DEFAULT NULL,
    `status` text DEFAULT NULL,
    `valor` varchar(255) NOT NULL,
    `bottoken` varchar(255) NOT NULL,
    `botid` varchar(255) NOT NULL,
    `tempoteste` varchar(255) NOT NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
  
if ($result50 = mysqli_query($conn, $create)) {
  echo "<script>alert('Instalado com sucesso!');</script>";
  echo "<script>window.location.href = 'index.php';</script>";
} else {
  echo "<script>alert('Erro ao instalar!');</script>";
}
?>
