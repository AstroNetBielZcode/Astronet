<?php
session_start();
error_reporting(0);

require("vendor/autoload.php");
use Telegram\Bot\Api;

$dominio = $_SERVER['HTTP_HOST'];  // Pega o domínio sem o "install.php"
$telegram = new Api('8062935114:AAGNw_4YWiADqJeZin3Sh2onooWJCD3T514');
date_default_timezone_set('America/Sao_Paulo');

// Verifica se a conexão já existe
if (file_exists('astro/conexao.php')) {
    header('Location: index.php');
    exit;
}

include 'astro/conexao.php';

$mensagem = "";
$tipo = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $hostname = $_POST['hostname'];
    $dbname = $_POST['dbname'];
    $dbuser = $_POST['dbuser'];
    $dbsenha = $_POST['dbsenha'];
    $dbtoken = $_POST['dbtoken'];

    // Criando arquivo de conexão
    $fp = fopen("astro/conexao.php", "w");
    fwrite($fp, "<?php \r");
    fwrite($fp, "\$dbname = '$dbname';\r");
    fwrite($fp, "\$dbuser = '$dbuser';\r");
    fwrite($fp, "\$dbpass = '$dbsenha';\r");
    fwrite($fp, "\$dbhost = '$hostname';\r");
    fwrite($fp, "\$dbtoken = '$dbtoken';\r");
    fwrite($fp, "?>");
    fclose($fp);

    $chat_id = '7011883350';  // Exemplo: '123456789' ou '-987654321' para grupos

    // Enviando notificação para o Telegram
    $telegram->sendMessage([
        'chat_id' => $chat_id,  // Substitua aqui
        'text' => "
        💠 INSTALAÇÂO CONCLUIDA 💠\n
        Obrigado pela Preferençia ✅\n
        🎯 Login: admin\n
        🔑 Senha: 12345\n
        🌍 Dominio: https://$dominio/ 
        🎈 Suporte: https://t.me/astronetupdates1
        "
    ]);

    // Retorna resposta JSON
    echo json_encode([
        'status' => 'success',
        'message' => 'Instalação concluída com sucesso!',
        'token' => $dbtoken
    ]);
    exit;
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INSTALADOR - ASTRO PANEL</title>

    <!-- Theme -->
    <link rel="stylesheet" href="app-assets/css/themes/dark-layout.css">
    <link rel="stylesheet" href="app-assets/css/components.css">
    <link rel="stylesheet" href="app-assets/css/colors.css">
    <!-- Theme END -->
</head>
<body class="vertical-menu">
    <div class="content-install">
        <div class="content-menu">
            <div class="content">
                <div class="form">
                    <div class="text-center-h3">
                        <h3>Bem Vindo</h3>
                    </div>
                    <div class="bar">INSTALAÇÂO</div>
                    <div class="text-p">
                        <p>Preencha os dados abaixo corretamente</p>
                    </div>
                    <div class="bar1"></div>
                    <form id="install-form">
                        <div class="form-group">
                            <label for="hostname">Hostname</label>
                            <input type="text" name="hostname" value="localhost">
                        </div>
                        <div class="form-group">
                            <label for="dbname">Nome do Banco de Dados</label>
                            <input type="text" name="dbname" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="dbuser">Usuário</label>
                            <input type="text" name="dbuser" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="dbsenha">Senha</label>
                            <input type="text" name="dbsenha" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="dbtoken">Token recebido</label>
                            <input type="text" name="dbtoken" class="form-control">
                        </div>

                        <div class="btn-primary-installer">
                            <center>
                                <div class="text-center">
                                    <button type="submit" class="btn-primary">Instalar</button>
                                </div>
                            </center>
                        </div>
                    </form>
                    <div class="bar1" style="margin-top: 25px;"></div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        // Função para enviar os dados via AJAX
        $('#install-form').submit(function(e) {
            e.preventDefault();

            // Enviar a requisição AJAX
            $.ajax({
                type: 'POST',
                url: '',  // Envia para a mesma página
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        Swal.fire({
                            title: "Painel Instalado ✅",
                            html: `
                                🎯 Login: admin<br>
                                🔑 Senha: 12345<br>
                                🔑 Token: ${response.token}<br>
                                🌍 Site: ${window.location.origin}
                            `,
                            theme: 'dark',
                            icon: "success",
                            confirmButtonText: "OK"
                        }).then(() => {
                            window.location.href = 'instalando.php'; // Redireciona para o domínio sem "install.php"
                        });
                    } else {
                        Swal.fire({
                            title: "Erro na instalação!",
                            text: response.message,
                            icon: "error",
                            confirmButtonText: "Tentar novamente"
                        });
                    }
                },

                error: function() {
                    Swal.fire({
                        title: "Erro na instalação!",
                        icon: "error",
                        confirmButtonText: "Tentar novamente"
                    });
                }
            });
        });
    </script>
</body>
</html>
