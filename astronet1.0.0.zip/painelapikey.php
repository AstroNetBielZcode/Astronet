<?php

require 'astro/conexao.php';

$dbtoken = $dbtoken;
$dominio = $_SERVER['HTTP_HOST'];

// Define a URL da API
$apiUrl = 'https://astronetpainelapi.rf.gd/api/tokenpainelapi.php';

// Cria a URL completa para a requisição
$requestUrl = $apiUrl . '?token=' . urlencode($dbtoken) . '&dominio=' . urlencode($dominio);

// Inicializa o cURL
$ch = curl_init();

// Configurações do cURL
curl_setopt($ch, CURLOPT_URL, $requestUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Desabilitar a verificação SSL
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);  // Desabilitar verificação do certificado SSL
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);      // Não verificar o host do certificado

// Executa a requisição
$response = curl_exec($ch);

// Verifica se ocorreu algum erro no cURL
if(curl_errno($ch)) {
    echo "<script>alert('Erro ao acessar a API: " . curl_error($ch) . "');</script>";
    exit();
}

// Fecha a conexão cURL
curl_close($ch);

// Decodifica a resposta JSON
$data = json_decode($response, true);

// Verifica se a decodificação foi bem-sucedida
if ($data === null) {
    echo "<script>alert('Erro ao processar a resposta da API.');</script>";
    exit();
}

// Verifica a validade do token
if ($data['status'] === 'success') {
    $daysRemaining = isset($data['days_remaining']) ? $data['days_remaining'] : 'Desconhecida';
} else {
    echo "<script>alert('Token Inválido!');</script>";
}
?>
