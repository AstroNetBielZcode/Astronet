<?php
include("../astro/conexao.php"); // Conexão com o banco de dados

// Conexão com o banco de dados
try {
    $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    if (mysqli_connect_errno()) {
        throw new Exception("Erro na conexão com o banco de dados: " . mysqli_connect_error());
    }
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => "Erro: " . $e->getMessage()]);
    exit();
}

// Verifica se o ID foi recebido via POST
if (!empty($_POST['id'])) {
    $id = $_POST['id'];

    // Inicializa arrays para atualização dinâmica
    $updates = [];
    $params = [];
    $types = "";

    // Lista dos campos que podem ser atualizados
    $fields = [
        'ip' => 's',
        'usuario' => 's',
        'senha' => 's'
    ];

    // Percorre os campos e adiciona apenas os que foram enviados e não estão vazios
    foreach ($fields as $field => $type) {
        if (isset($_POST[$field]) && $_POST[$field] !== '') {
            $updates[] = "$field = ?";
            $params[] = $_POST[$field];
            $types .= $type;
        }
    }

    // Verifica se há algo para atualizar
    if (!empty($updates)) {
        $sql = "UPDATE servidores SET " . implode(", ", $updates) . " WHERE id = ?";
        $stmt = $conn->prepare($sql);

        if ($stmt === false) {
            echo json_encode(["status" => "error", "message" => "Erro na preparação da consulta: " . $conn->error]);
            exit();
        }

        // Adiciona o ID ao final dos parâmetros
        $params[] = $id;
        $types .= "i"; // ID é inteiro

        // Vincula os parâmetros dinamicamente
        $stmt->bind_param($types, ...$params);

        // Executa a consulta e verifica se foi bem-sucedida
        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Servidor atualizado com sucesso."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Falha ao atualizar o servidor: " . $stmt->error]);
        }

        // Fecha a declaração preparada
        $stmt->close();
    } else {
        echo json_encode(["status" => "error", "message" => "Nenhum dado para atualizar."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "ID não recebido."]);
}

// Fecha a conexão com o banco de dados
$conn->close();
?>
