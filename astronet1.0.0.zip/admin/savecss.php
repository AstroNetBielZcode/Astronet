<?php
include('../astro/conexao.php');
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$data = json_decode(file_get_contents('php://input'), true);
$css = $data['css'];  // Recebe o conteúdo CSS enviado via POST

// SQL para atualizar o CSS no banco de dados
$sql = "UPDATE configs SET corfundologo = ? WHERE id = 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $css);
$stmt->execute();

// Verifica se a atualização foi bem-sucedida
if ($stmt->affected_rows > 0) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Erro ao salvar o tema']);
}

$stmt->close();
$conn->close();
?>
