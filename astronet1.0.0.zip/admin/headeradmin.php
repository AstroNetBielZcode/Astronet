<?php

error_reporting(0);


session_start();
require '../astro/conexao.php';


require("../vendor/autoload.php");
use Telegram\Bot\Api;
$dominio = $_SERVER['HTTP_HOST'];
$telegram = new Api('8062935114:AAGNw_4YWiADqJeZin3Sh2onooWJCD3T514');
date_default_timezone_set('America/Sao_Paulo');

try {
    $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
} catch (mysqli_sql_exception $e) {
    header('Location: install.php');
    exit;
}

if(!isset($_SESSION['login']) and !isset($_SESSION['senha'])){
    session_destroy();
    unset($_SESSION['login']);
    unset($_SESSION['senha']);
    header('location:../index.php');
}


$sql = "SELECT * FROM configs";
$result = $conn -> query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $nomepainel = $row["nomepainel"];
        $logo = $row["logo"];
        $icon = $row["icon"];
        $csspersonali = $row["corfundologo"];
    }
}

$tokenvb = "SELECT * FROM accounts WHERE id = '".$_SESSION['iduser']."'";
$resultvb = mysqli_query($conn, $tokenvb);
$rowvb = mysqli_fetch_assoc($resultvb);
$tokenvenda = $rowvb['tokenvenda'];

$sql80 = "SELECT * FROM configs";
$result80 = $conn -> query($sql80);
if ($result80->num_rows > 0) {
    while ($row = $result80->fetch_assoc()) {
        $tempodeteste = $row['tempodeteste'];
        $catpadrao = $row['catpadrao'];
    }
}


// Informações de pagamento 
$chavepix = "70162c24-2gh9-484f-z568-b2882c1f13dc";
$urlapipay = "";


date_default_timezone_set('America/Sao_Paulo'); 

$hora = date('H');

if ($hora >= 6 && $hora < 12) {
    $periodo = 'Bom dia';
} elseif ($hora >= 12 && $hora < 18) {
    $periodo = 'Boa tarde';
} elseif ($hora >= 18 && $hora < 24) {
    $periodo = 'Boa noite';
} else {
    $periodo = 'Boa madrugada';
}

if (!isset($_SESSION['show_text'])) {
    // Define a variável de sessão para garantir que o texto não será mostrado novamente
    $_SESSION['show_text'] = true;
    
    // Texto a ser exibido
    $text = "Bem-vindo ao painel de administração!";
} else {
    $text = "";
}


//consulta usuarios expirados
date_default_timezone_set('America/Sao_Paulo');
$data = date('Y-m-d H:i:s');
$slq5 = "SELECT * FROM ssh_accounts WHERE byid = '".$_SESSION['iduser']."' and expira < '$data'";
$result5 = mysqli_query($conn, $slq5);
$totalvencidos = mysqli_num_rows($result5);

$sql3 = "SELECT * FROM ssh_accounts WHERE byid = '".$_SESSION['iduser']."'";
//contar quantos ssh tem
$result3 = mysqli_query($conn, $sql3);
$totalusuarios = mysqli_num_rows($result3); 

$sql8 = "SELECT * FROM accounts WHERE byid = '".$_SESSION['iduser']."'";
//contar quantos revedendores tem
$result7 = mysqli_query($conn, $sql8);
$totalrevenda = mysqli_num_rows($result7); 

$sql4 = "SELECT * FROM ssh_accounts";
//contar quantos ssh tem no total
$result4 = mysqli_query($conn, $sql4);
$totalusuariosglobal = mysqli_num_rows($result4); 

$sql6 = "SELECT COUNT(*) FROM accounts WHERE id > 1";  
$result5 = mysqli_query($conn, $sql6);

if ($result5) {
    $row = mysqli_fetch_row($result5);
    $totalrevendaglobal = $row[0];  
}

$slq7 = "SELECT sum(valor) AS valor  FROM pagamentos where byid='".$_SESSION['iduser']."' and status='Aprovado'";
$result6 = mysqli_query($conn, $slq7);
$row3 = mysqli_fetch_assoc($result6);
$totalvendido = $row3['valor'];
$totalvendido = number_format($totalvendido, 2, ',', '.');


$sql16 = "SELECT * FROM ssh_accounts WHERE status = 'Online' and byid = '".$_SESSION['iduser']."'";
$result16 = mysqli_query($conn, $sql16);
$totalonline = mysqli_num_rows($result16);
$seusonlines = $totalonline;

//Conta o total de onlines ssh
$sql11 = "SELECT * FROM ssh_accounts WHERE status = 'Online'";
$result11 = mysqli_query($conn, $sql11);
$row16 = mysqli_fetch_assoc($result11);
$totalonlineglobal = mysqli_num_rows($result11);


$sql4 = "SELECT * FROM servidores";
$result4 = mysqli_query($conn, $sql4);
$totalservidores = mysqli_num_rows($result4);


$slq3 = "SELECT sum(valor) AS valor  FROM pagamentos where byid='".$_SESSION['iduser']."' and status='Aprovado'";
$result3 = mysqli_query($conn, $slq3);
$row3 = mysqli_fetch_assoc($result3);
$totalvendido = $row3['valor']; 
$totalvendido = number_format($totalvendido, 2, ',', '.');


$url = "https://{$dominio}/comprar.php?token={$tokenvenda}";

$id = $_SESSION['iduser'];

// Puxa todas as categorias
$sqlCategorias = "SELECT id, nome FROM categorias";  // Ajuste para o nome da tabela de categorias
$resultCategorias = $conn->query($sqlCategorias);

// Puxa a categoria padrão para o usuário
$sqlDefault = "SELECT catpadrao FROM configs WHERE id = ?";
$stmtDefault = $conn->prepare($sqlDefault);
if ($stmtDefault === false) {
    die('Erro ao preparar a consulta SELECT catpadrao: ' . $conn->error);
}
$stmtDefault->bind_param("i", $id);
$stmtDefault->execute();
$stmtDefault->bind_result($defaultCategoryId);
$stmtDefault->fetch();
$stmtDefault->close();

// Variável para passar para o JavaScript
$alertType = '';
$alertTitle = '';
$alertText = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['salvar_dados'])) {
    // Pega a categoria selecionada pelo usuário e o tempo de teste
    $categoriaSelecionada = $_POST['categoriacompra'] ?? null;
    $tempoTeste = $_POST['tempo'] ?? null;

    if ($categoriaSelecionada === null || $tempoTeste === null) {
        die('Erro: Campos obrigatórios não preenchidos.');
    }

    // Atualiza ou insere a categoria padrão e o tempo de teste no banco de dados
    $sqlCheck = "SELECT id FROM configs WHERE id = ?";
    $stmtCheck = $conn->prepare($sqlCheck);
    if ($stmtCheck === false) {
        die('Erro ao preparar a consulta SELECT id FROM configs: ' . $conn->error);
    }
    $stmtCheck->bind_param("i", $id);
    $stmtCheck->execute();
    $stmtCheck->store_result();

    if ($stmtCheck->num_rows > 0) {
        // Se já existe uma configuração, atualiza a categoria e o tempo de teste
        $sqlUpdate = "UPDATE configs SET catpadrao = ?, tempodeteste = ? WHERE id = ?";
        $stmt = $conn->prepare($sqlUpdate);
        if ($stmt === false) {
            die('Erro ao preparar a consulta UPDATE: ' . $conn->error);
        }
        $stmt->bind_param("iii", $categoriaSelecionada, $tempoTeste, $id);
    } else {
        // Se não existe, insere uma nova configuração
        $sqlInsert = "INSERT INTO configs (id, catpadrao, tempodeteste) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sqlInsert);
        if ($stmt === false) {
            die('Erro ao preparar a consulta INSERT: ' . $conn->error);
        }
        $stmt->bind_param("iii", $id, $categoriaSelecionada, $tempoTeste);
    }

    // Executa a consulta
    if ($stmt->execute()) {
        // Definir os dados do SweetAlert para sucesso
        $alertType = 'success';
        $alertTitle = 'Sucesso!';
        $alertText = 'Dados Salvos com sucesso!';
        
    } else {
        // Definir os dados do SweetAlert para erro
        $alertType = 'error';
        $alertTitle = 'Erro!';
        $alertText = 'Ocorreu um erro ao atualizar os dados.';
    }

    // Fecha as declarações
    $stmt->close();
    $stmtCheck->close();
}



// Sistema de atualizações
$versao_atual = "1.0 | MB"; // Defina a versão atual do painel

$versoes = [
    "1.0 | MB" => "https://github.com/seu-repo/seu-projeto/archive/refs/tags/v1.0.zip",
];

// Pegando a última versão disponível no GitHub
$ultima_versao = array_key_last($versoes);

$status = ($versao_atual == $ultima_versao) ? 
    "<span style='color:#71dd37;'>Seu painel está atualizado!</span>" : 
    "<span style='color: red;'>⚠️ Seu painel está desatualizado! Última versão: $ultima_versao</span>";

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="<?php echo $icon; ?>" type="image/x-icon">
    <title><?php echo $nomepainel; ?> - Painel Administrativo</title>

    <!-- Theme -->
    <link rel="stylesheet" href="../app-assets/css/themes/semi-dark-layout.css">
    <link rel="stylesheet" href="../app-assets/css/themes/dark-layout.css">
    <link rel="stylesheet" href="../app-assets/css/components.css">
    <!-- END - Theme -->

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" />

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- END - Bootstrap -->

    <!-- Swal.fire -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@5/dark.css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>

    <!-- END - SweetAlert2 -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">  

    <style>
        <?php echo $csspersonali ?>
    </style>
</head>
<body class="vertical-menu-body bootstrap-color" id="data-value-carregando">

    <!-- NOTIFICAÇÂO ADMIN -->
    <?php

    if (!isset($_SESSION['notification_shown'])) {
        $_SESSION['notification_shown'] = true; // Marca que a notificação foi exibida
    ?>
        <script>
        Swal.fire({
            title: 'Olá 😉 Bem Vindo',
            html: `
                📢 Versão atual do painel: Versão 1.0 
                <br><br>
                🎉 ATUALIZAÇÕES RECENTES 🎉
                <br><br>
                🛠 <strong>Melhorias e Otimizações do Painel</strong>
                <br>
                - API de Bot Telegram ja sendo trabalhada
                <br>
                - Em breve teremos api de whatsapp
                <br>
                - Melhorias no CSS e modernizado
                <br>
                - Trabalhando na otimização do painel
                <br><br>
                Obrigado por utilizar o nosso painel de gerenciamento SSH! Estamos trabalhando para fazer melhorias para você usar sem erro.
                <br>
                Fique atento no grupo de suporte para mais atualizações que teremos em breve!
                <br><br>
                💠 Atenciosamente, BielZcode ❤
                <br><br>
                <a href="https://t.me/astronetupdates1" target="_blank" style="color: #3085d6;">Suporte</a>
            `,
            icon: null,  
            background: '#222',  
            color: '#fff',       
            confirmButtonText: 'OK',
            showCancelButton: false,
            reverseButtons: true,  
        })
    </script>

    <?php
    }
    ?>

    <div id="rodape" class="rodape-horizontal">
        <div class="footer-nav vertical-texts">
            <button class="btn-open" onclick="toggleSidebar()" id="open-btn"><i class="fa-solid fa-bars"></i></button>
            <div class="areaclient">
                <div class="bar-horizontal"></div>
                <p>Area do Painel</p>
                <svg class="svgs mobile-size" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            </div>
            <button class="btn-primary-sucess m6-0" id="openModal"><svg class="svgs" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-hand-coins"><path d="M11 15h2a2 2 0 1 0 0-4h-3c-.6 0-1.1.2-1.4.6L3 17"/><path d="m7 21 1.6-1.4c.3-.4.8-.6 1.4-.6h4c1.1 0 2.1-.4 2.8-1.2l4.6-4.4a2 2 0 0 0-2.75-2.91l-4.2 3.9"/><path d="m2 16 6 6"/><circle cx="16" cy="9" r="2.9"/><circle cx="6" cy="5" r="3"/></svg> Renovar Painel</button>
            <button class="btn-primary-sucess m6-0" onclick="criarteste()"><svg class="svgs" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-plus"><circle cx="12" cy="12" r="10"/><path d="M8 12h8"/><path d="M12 8v8"/></svg> Teste Rapido</button>
            <div class="areaclient">
                <div class="bar-horizontal"></div>
                <p>Area do Client</p>
                <svg class="svgs mobile-size" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            </div>
            <button class="btn-primary-sucess m6-0" id="openModal"><svg class="svgs" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-headset"><path d="M3 11h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-5Zm0 0a9 9 0 1 1 18 0m0 0v5a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3Z"/><path d="M21 16v2a4 4 0 0 1-4 4h-5"/></svg> Suporte</button>
            <button class="btn-primary-sucess m6-0" id="openModal"><svg class="svgs" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-book-marked"><path d="M10 2v8l3-3 3 3V2"/><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20"/></svg> Documentario Api</button>
            <script>
                function criarusuario() {
                    window.location.href = 'criarteste.php';
                }
                function conta() {
                    window.location.href = 'perfil.php';
                }
            </script>
            <div class="avatar bg-success mr-1">
                <div class="perfil-perfomace-primary">
                    <div class="perfil-primary">
                        <div class="perfil" id="perfil">
                            <p onclick="conta()">
                                <img src="<?php echo $icon; ?>" alt="icon">
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="text">
        <div class="text-alert">
            <p><span><?php echo $periodo; ?></span><span class="login-name" style="margin-left: 5px;"><?php echo $_SESSION['login']; ?>🎉</span></p>
        </div>
        <div class="update">
            <!-- Sistema de Atualização -->
            <form class="d-inline-block" onsubmit="event.preventDefault(); checkForUpdate();">
                <div class="d-flex align-items-center">
                    <label for="version-select" class="version me-2 mb-0">
                        <small><strong>Versão Atual:</strong> <?= $currentVersion; ?></small>
                    </label>
                    <select name="version-select" id="version-select" class="form-select form-select-sm w-auto" style="width: 130px;">
                        <option value="">Selecione</option>
                        <?php foreach ($updatesData['updates'] as $update): ?>
                            <option value="<?= $update['url']; ?>" data-version="<?= $update['version']; ?>">
                                <?= $update['version']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" id="update-btn" class="btn btn-primary btn-sm ms-2">Atualizar</button>
                </div>
            </form>

            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
            <script>
            document.addEventListener("DOMContentLoaded", function() {
                fetch('https://raw.githubusercontent.com/AstroNetBielZcode/Astronet/refs/heads/main/updates.json')
                    .then(response => response.json())
                    .then(data => {
                        let select = document.getElementById('version-select');
                        select.innerHTML = ''; // Limpa as opções
                        data.updates.forEach(update => {
                            let option = document.createElement('option');
                            option.value = update.url;
                            option.textContent = `Versão ${update.version}`;
                            select.appendChild(option);
                        });
                    })
                    .catch(error => {
                        console.error("Erro ao carregar versões:", error);
                        Swal.fire({
                            title: "Erro",
                            text: "Não foi possível carregar as atualizações.",
                            icon: "error",
                            background: "#1e1e2f",
                            customClass: {
                                title: 'swal2-title-dark',
                                htmlContainer: 'swal2-text-dark'
                            }
                        });
                    });
            });

            function checkForUpdate() {
                let select = document.getElementById('version-select');
                let updateUrl = select.value;
                let version = select.options[select.selectedIndex].text;

                if (!updateUrl) {
                    Swal.fire({
                        title: "Atenção",
                        text: "Selecione uma versão para atualizar.",
                        icon: "warning",
                        background: "#1e1e2f",
                        customClass: {
                            title: 'swal2-title-dark',
                            htmlContainer: 'swal2-text-dark'
                        }
                    });
                    return;
                }

                Swal.fire({
                    title: "Atualizar para " + version + "?",
                    text: "Deseja baixar e instalar esta versão?",
                    icon: "info",
                    showCancelButton: true,
                    confirmButtonText: "Sim, atualizar!",
                    cancelButtonText: "Cancelar",
                    background: "#1e1e2f",
                    customClass: {
                        title: 'swal2-title-dark',
                        htmlContainer: 'swal2-text-dark'
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Exibe alerta de instalação em andamento
                        Swal.fire({
                            title: "Instalando...",
                            text: "Aguarde enquanto a atualização está sendo instalada.",
                            icon: "info",
                            allowOutsideClick: false,
                            background: "#1e1e2f",
                            customClass: {
                                title: 'swal2-title-dark',
                                htmlContainer: 'swal2-text-dark'
                            },
                            didOpen: () => {
                                Swal.showLoading();
                            }
                        });

                        fetch("../update.php?url=" + encodeURIComponent(updateUrl))
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    Swal.fire({
                                        title: "Atualização concluída!",
                                        text: "Seu sistema foi atualizado com sucesso para " + version + ".",
                                        icon: "success",
                                        background: "#1e1e2f",
                                        customClass: {
                                            title: 'swal2-title-dark',
                                            htmlContainer: 'swal2-text-dark'
                                        }
                                    }).then(() => {
                                        location.reload();
                                    });
                                } else {
                                    throw new Error(data.message || "Erro desconhecido.");
                                }
                            })
                            .catch(error => {
                                Swal.fire({
                                    title: "Erro na atualização!",
                                    text: "Ocorreu um erro ao instalar a atualização: " + error.message,
                                    icon: "error",
                                    background: "#1e1e2f",
                                    customClass: {
                                        title: 'swal2-title-dark',
                                        htmlContainer: 'swal2-text-dark'
                                    }
                                });
                            });
                    }
                });
            }
            </script>

            <style>
            /* Estiliza o título e o texto do SweetAlert2 para branco */
            .swal2-title-dark {
                color: #ffffff !important;
            }

            .swal2-text-dark {
                color: #ffffff !important;
            }
            </style>
            <div class="att-text">
                <p><?= $status ?></p>
            </div>
        </div>
    </div>
    <div class="validity">
        <p><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-clock"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>Validade: <span class="text-validity"><?php echo $validade; ?><p class="text-vali">Infinito</p></span></p>
    </div>
           
    <div id="modalPix" style="display: none;" class="content-renovate">
            <div class="top-pix">
                <div class="pack">
                    <p>NºPedido: <span id="numeroPedido"></span></p>
                    <button class="btn-close" onclick="fecharModal()"><i class="fa-solid fa-x"></i></button>
                </div>
            </div>
            <div class="bar-content">INFORMAÇÔES</div>
            <div class="bottom-pix">
                <div class="valor">
                    <p>Valor a Pagar: 30 R$</p>
                </div>
                <p>Após Efetuar o pagamento Aguarde o Pagamento ser Concluido</p>
                <div class="content-info">
                    <div id="qrCodeResult"></div>
                </div>
                <div class="bar4" style="margin-top: 20px;margin-bottom: 20px;"></div>
                <input class="chave-pix" id="chave-pix" type="text" value="<?php echo $chavepix; ?>" readonly>
                <p>Seu Pagamento expirara em: <span id="timer"></span></p>
                
                <!-- Botões do pix -->
                <div class="buttons-pix">
                    <button onclick="copyChavePix()">Copiar</button>
                    <button>Verificar Pagamento</button>
                </div>
            </div>
        </div>

    <div class="overlay" id="overlay"></div>

    <script>
        // Abrir o modal quando clicar no botão
        document.getElementById('openModal').addEventListener('click', function() {
            document.getElementById('modalPix').style.display = 'block'; 
            document.getElementById('overlay').style.display = 'block'; 
        });

        // Fechar o modal
        function fecharModal() {
            document.getElementById('modalPix').style.display = "none";
            document.getElementById('overlay').style.display = "none";
        }

        document.getElementById('openModal').addEventListener('click', function() {

            // Função para formatar o tempo
            function formatTime(seconds) {
                const minutes = Math.floor(seconds / 60);
                const remainingSeconds = seconds % 60;
                return `${minutes < 10 ? '0' : ''}${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
            }

            // Função para atualizar a contagem regressiva
            function updateTimer() {
                let endTime = localStorage.getItem('endTime');
                
                if (!endTime) {
                    // Se não houver tempo salvo, define o tempo de término como 10 minutos a partir de agora
                    endTime = Date.now() + 10 * 60 * 1000; // 10 minutos em milissegundos
                    localStorage.setItem('endTime', endTime); // Armazena o tempo no localStorage
                }

                const timeRemaining = endTime - Date.now();
                
                if (timeRemaining <= 0) {
                    // Se o tempo acabou, reinicia o timer
                    localStorage.removeItem('endTime');
                    document.getElementById('timer').innerText = "Tempo expirado";

                    // Gerar o número do pedido após o tempo acabar
                    gerarNumeroPedido();

                } else {
                    // Exibe o tempo restante
                    document.getElementById('timer').innerText = formatTime(Math.floor(timeRemaining / 1000));
                    setTimeout(updateTimer, 1000); // Atualiza o timer a cada segundo
                }
            }

            // Inicia a contagem regressiva
            updateTimer();

            // Função para gerar o número do pedido
            function gerarNumeroPedido() {
                const numeroPedido = Math.floor(Math.random() * 900000000) + 100000000; // Número aleatório de 9 dígitos
                document.getElementById('numeroPedido').innerText = numeroPedido;
            }

            // Verifica se o número do pedido já foi gerado
            if (!localStorage.getItem('numeroPedido')) {
                // Se não houver número gerado, chama a função de gerar o número
                gerarNumeroPedido();
            } else {
                // Se o número já foi gerado, exibe o número salvo
                document.getElementById('numeroPedido').innerText = localStorage.getItem('numeroPedido');
            }

        });

        const chavePix = "<?php echo $chavepix; ?>";

        // Geração do QR Code Pix
        const pixUrl = `https://api.qrserver.com/v1/create-qr-code/?data=${chavePix}&size=150x150`;

        // Exibir o QR Code na página
        document.getElementById('qrCodeResult').innerHTML = `<img src="${pixUrl}" alt="QR Code Pix">`;

        function copyChavePix(text) {
            // Cria um campo de input temporário
            var input = document.getElementById("chave-pix");

            // Seleciona o texto do input
            input.select();
            input.setSelectionRange(0, 99999); // Para dispositivos móveis

            // Copia o texto selecionado para a área de transferência
            document.execCommand("copy");

            // Exibe o SweetAlert
            Swal.fire({
                title: 'Sucesso!',
                text: 'Link copiado para a área de transferência!',
                icon: 'success',
                color: "#ffffff",
                background: "#1e1e2f",
                confirmButtonText: 'OK'
            });
        }

    </script>
    <div class="carder-menu-r8">
        <div class="vertical-menu-r8">
            <div class="main-menu">
                <div class="stat-items">
                    <div class="items">
                        <div class="row">
                            <i class='fas fa-user-friends fa-2x text-primary'></i>
                            <p class="text-stat">Meus Onlines</p>
                            <span><?php echo $seusonlines; ?></span>
                        </div>
                    </div>
                </div>
                <div class="stat-items">
                    <div class="items">
                        <div class="row">
                            <i class='fas fa-globe fa-2x text-success'></i>
                            <p class="text-stat">Todos Onlines</p>
                            <span><?php echo $totalonlineglobal; ?></span>
                        </div>
                    </div>
                </div>  
                <div class="stat-items">
                    <div class="items">
                        <div class="row">
                            <i class='fas fa-store fa-2x text-warning1'></i>
                            <p class="text-stat">Meus Revendedores</p>
                            <span><?php echo $totalrevenda; ?></span>
                        </div>
                    </div>
                </div>
                <div class="stat-items">
                    <div class="items">
                        <div class="row">
                            <i class='fas fa-people-arrows fa-2x text-danger'></i>
                            <p class="text-stat">Revendedores Global</p>
                            <span><?php echo $totalrevendaglobal; ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="main-menu">
                <div class="stat-items">
                    <div class="items">
                        <div class="row">
                            <i class='fas fa-user fa-2x text-info'></i>
                            <p class="text-stat">Meus Usuários</p>
                            <span><?php echo $totalusuarios; ?></span>
                        </div>
                    </div>
                </div>
                <div class="stat-items">
                    <div class="items">
                        <div class="row">
                            <i class='fas fa-users fa-2x text-secondary'></i>
                            <p class="text-stat">Usuários Globais</p>
                            <span><?php echo $totalusuariosglobal; ?></span>
                        </div>
                    </div>
                </div>
                <div class="stat-items">
                    <div class="items">
                        <div class="row">
                            <i class='fas fa-check-circle fa-2x text-success'></i>
                            <p class="text-stat">Pagamentos Sucedidos</p>
                            <span><?php echo $totalvendido; ?></span>
                        </div>
                    </div>
                </div>
                <div class="stat-items">
                    <div class="items">
                        <div class="row">
                            <i class='fas fa-server fa-2x text-primary'></i>
                            <p class="text-stat">Total de Servidores</p>
                            <span><?php echo $totalservidores; ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="main-carder">
        <div class="carder">
            <table class="links">
                <div class="alert-text1">
                    <p>Links Utilizaveis</p>
                </div>
                <div class="card-content">
                    <div class="card-body">
                        <p class="text-warning">
                            ⚠️ Não esqueça!! Clique em <span class="text-primary">"Gerar novo link"</span> se for a primeira vez acessando o painel.
                        </p>

                             <!-- Cron de backup -->
                            <div class="mb-4">
                                <div class="divider-text text-primary">Cron de backup</div>
                                <div class="input-group">
                                    <input type="text" class="form-control" value="<?php echo "https://$dominio/backup.php"; ?>" readonly>
                                    <button class="btn btn-primary" type="button" onclick="copyToClipboard('https://<?php echo $dominio; ?>/backup.php')">Copiar</button>
                                </div>
                            </div>

                            <!-- Links de acesso -->
                            <div class="mb-4">
                                <div class="divider-text text-primary">Vendas Painel Revenda</div>
                                <div class="input-group">
                                    <input type="text" class="form-control" value="<?php echo "https://$dominio/revenda.php?token="?><?php echo $tokenvenda; ?>" readonly>
                                    <button class="btn btn-primary" type="button" onclick="copyToClipboard('https://<?php echo $dominio; ?>/revenda.php?token=')">Copiar</button>
                                </div>
                            </div>

                            <div class="mb-4">
                                <div class="divider-text text-primary">Vendas Usuário Final</div>
                                <div class="input-group">
                                    <input type="text" class="form-control" value="<?php echo "https://$dominio/comprar.php?token="?><?php echo $tokenvenda; ?>" readonly>
                                    <button class="btn btn-primary" type="button" onclick="copyToClipboard('<?php echo $url; ?>')">Copiar</button>
                                </div>
                            </div>

                            <div class="mb-4">
                                <div class="divider-text text-primary">Link Teste Automático</div>
                                <div class="input-group">
                                    <input type="text" class="form-control" value="<?php echo "https://$dominio/criarteste.php?token="?><?php echo $tokenvenda; ?>" readonly>
                                    <button class="btn btn-primary" type="button" onclick="copyToClipboard('https://<?php echo $dominio; ?>/criarteste.php?token=<?php echo $tokenvenda; ?>')">Copiar</button>
                                </div>
                            </div>
                            <script>
                            function copyToClipboard(text) {
                                // Cria um campo de input temporário
                                let tempInput = document.createElement("input");
                                tempInput.value = text;
                                document.body.appendChild(tempInput);

                                // Seleciona e copia o texto
                                tempInput.select();
                                tempInput.setSelectionRange(0, 99999); // Para dispositivos móveis
                                document.execCommand("copy");

                                // Remove o campo de input
                                document.body.removeChild(tempInput);

                                // Exibe o SweetAlert
                                Swal.fire({
                                    title: 'Sucesso!',
                                    text: 'Link copiado para a área de transferência!',
                                    icon: 'success',
                                    color: "#ffffff",
                                    background: "#1e1e2f",
                                    confirmButtonText: 'OK'
                                });
                            }

                            </script>
                        
                        <!-- Botão de Gerar Novo Link -->
                        <form action="home.php" method="post">
                            <div class="text-center my-4">
                                <button class="btn-grtl btn-success" id="gerarlink" type="submit" name="gerarlink" id="gerarlink">Gerar Novo Link</button>
                            </div>
                        </form>
                        <?php
                            if(isset($_POST['gerarlink'])){
                                $codigo = rand(100000000000,999999999999);
                                $id = $_SESSION['iduser'];
                                $sql = "UPDATE accounts SET tokenvenda = '$codigo' WHERE id = '$id'";
                                $result = $conn -> query($sql);
                                echo "<meta http-equiv='refresh' content='0'>";
                            }
                        ?>

                        <!-- HTML para o formulário de categoria -->
                        <form method="POST">
                            <!-- Campo para selecionar a categoria -->
                            <div class="categoria-select">
                                <label for="categoria" class="form-label text-primary">
                                    Selecionar Categoria:
                                </label>
                                <div class="input-group">
                                    <input type="text" name="categoriacompra" class="form-control" placeholder="Id da Categoria Para Compra Automatica" value="<?php echo $catpadrao; ?>">
                                </div>
                            </div>

                            <!-- Tempo de Teste -->
                            <div class="tempo-test">
                                <label for="tempo" class="form-label text-primary">
                                    Tempo de Teste Máximo:
                                    <span class="text-danger">60</span> (em minutos)
                                </label>
                                <div class="input-group">
                                    <input type="number" class="form-control" name="tempo" id="tempo" value="<?php echo $tempodeteste; ?>" min="1">
                                </div>
                            </div>

                            <div class="text-center">
                                <button class="btn-dds btn-primary" type="submit" name="salvar_dados">Salvar dados</button>
                            </div>
                        </form>

                        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script> <!-- SweetAlert2 -->

                        <script>
                                // Verifica se há mensagem de alerta a ser exibida
                                <?php if ($alertType && $alertTitle && $alertText): ?>
                                    Swal.fire({
                                        title: '<?php echo $alertTitle; ?>',
                                        text: '<?php echo $alertText; ?>',
                                        color: "#ffffff",
                                        background: "#1e1e2f",
                                        icon: '<?php echo $alertType; ?>',
                                        confirmButtonText: 'OK'
                                    }).then((result) => {
                                        if (result.isConfirmed) {
                                            window.location.href = "home.php"; 
                                        }
                                    });
                                <?php endif; ?>
                        </script>

                        </form>
                        <?php
                            function anti_sql($input)
                            {
                                $seg = preg_replace_callback("/(from|select|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/i", function($match) {
                                    return '';
                                }, $input);
                                $seg = trim($seg);
                                $seg = strip_tags($seg);
                                $seg = addslashes($seg);
                                return $seg;
                            }
                            ?>
                    </div>
                </div>
            </table>
        </div>
    </div>  
    </div>
    <div class="sidebar">
        <img onclick="voltar()" src="<?php echo $logo; ?>" alt="logo">
        <script>
            function voltar() {
                    window.location.href = 'home.php';
            }
        </script>
        <div class="close-sidebar">
            <button class="close-btn" onclick="toggleSidebar()"><span><i class="fa-solid fa-xmark"></i></span></button>
        </div>
        <ul>
            <li class="inicio"><a href="home.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-house"><path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>Início</a></li>
            <li class="has-submenu">
                <a><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-users"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>Usuarios<svg class="arrow"xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-right"><path d="m9 18 6-6-6-6"/></svg></a>
                <ul class="submenu">
                    <li><a href="criarusuario.php">Criar Usuário</a></li>
                    <li><a href="listarbots.php">Criar Teste</a></li>
                    <li><a href="listarusuarios.php">Listar Usuários</a></li>
                    <li><a href="listarusuariosglobal.php">Listar Global</a></li>
                </ul>
            </li>
            <li class="has-submenu">
                <a><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-users-round"><path d="M18 21a8 8 0 0 0-16 0"/><circle cx="10" cy="8" r="5"/><path d="M22 20c0-3.37-2-6.5-4-8a5 5 0 0 0-.45-8.3"/></svg>Revendedores<svg class="arrow"xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-right"><path d="m9 18 6-6-6-6"/></svg></a>
                <ul class="submenu">
                    <li><a href="criarreven.php">Criar Revenda</a></li>
                    <li><a href="listarreven.php">Listar Revendas</a></li>
                    <li><a href="listartodosrevendas.php">Listar Global</a></li>
                </ul>
            </li>
            <li class="has-submenu">
                <a><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-layers-3"><path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m6.08 9.5-3.5 1.6a1 1 0 0 0 0 1.81l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9a1 1 0 0 0 0-1.83l-3.5-1.59"/><path d="m6.08 14.5-3.5 1.6a1 1 0 0 0 0 1.81l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9a1 1 0 0 0 0-1.83l-3.5-1.59"/></svg>Servidores<svg class="arrow"xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-right"><path d="m9 18 6-6-6-6"/></svg></a>
                <ul class="submenu">
                    <li><a href="criarservidor.php">Adicionar Servidor</a></li>
                    <li><a href="listarservidores.php">Listar Servidores</a></li>
                </ul>
            </li>
            <li>
                <a href="listarcategorias.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-layout-grid"><rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/></svg>Categorias</a>
            </li>
            <li>
                <a href="perfil.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user-pen"><path d="M11.5 15H7a4 4 0 0 0-4 4v2"/><path d="M21.378 16.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z"/><circle cx="10" cy="7" r="4"/></svg>Perfil</a>
            </li>
            <li class="has-submenu">
                <a><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-credit-card"><rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/></svg>Pagamentos<svg class="arrow"xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-right"><path d="m9 18 6-6-6-6"/></svg></a>
                <ul class="submenu">
                    <li><a href="configPag.php">Configurar</a></li>
                    <li><a href="listarPlanos.php">Planos</a></li>
                    <li><a href="cupom.php">Cupom</a></li>
                    <li><a href="vendas.php">Vendas</a></li>
                </ul>
            </li>
            <li>
                <a href="configAdmin.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-settings"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>Administração</a>
            </li>
            <li>
                <a href="lojaApks.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-store"><path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"/><path d="M2 7h20"/><path d="M22 7v3a2 2 0 0 1-2 2a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 16 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 12 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 8 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 4 12a2 2 0 0 1-2-2V7"/></svg>Lista de apks</a>
            </li>
            <li>
                <a href="editarcss.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-brush"><path d="m9.06 11.9 8.07-8.06a2.85 2.85 0 1 1 4.03 4.03l-8.06 8.08"/><path d="M7.07 14.94c-1.66 0-3 1.35-3 3.02 0 1.33-2.5 1.52-2 2.02 1.08 1.1 2.49 2.02 4 2.02 2.2 0 4-1.8 4-4.04a3.01 3.01 0 0 0-3-3.02z"/></svg>Editar css</a>
            </li>
            <li>
                <a href="checkuser.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user-round-check"><path d="M2 21a8 8 0 0 1 13.292-6"/><circle cx="10" cy="8" r="5"/><path d="m16 19 2 2 4-4"/></svg>CheckUser</a>
            </li>
            <li>
                <a href="whatsauto.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-phone"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>Whats Auto</a>
            </li>
            <li>
                <a href="whatsapi.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-phone"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>Whats Api</a>
            </li>
            <li>
                <a href="bot.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-send"><path d="M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z"/><path d="m21.854 2.147-10.94 10.939"/></svg>Bot Telegram</a>
            </li>
            <li>
                <a href="logs.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-door-open"><path d="M13 4h3a2 2 0 0 1 2 2v14"/><path d="M2 20h3"/><path d="M13 20h9"/><path d="M10 12v.01"/><path d="M13 4.562v16.157a1 1 0 0 1-1.242.97L5 20V5.562a2 2 0 0 1 1.515-1.94l4-1A2 2 0 0 1 13 4.561Z"/></svg>Logs</a>
            </li>
            <li><a href="../../logout.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-log-out"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>Sair</a></li>
            <li><a href="">Em Breve</a></li>
        </ul>
    </div>
    <footer>
        <p></p>
    </footer>
    <script>
        document.querySelectorAll('.has-submenu > a').forEach(function(menuLink) {
            menuLink.addEventListener('click', function(e) {
                e.preventDefault();
                var submenu = this.nextElementSibling;
                var isVisible = submenu.classList.contains('show');
                document.querySelectorAll('.submenu').forEach(function(sub) {
                    sub.classList.remove('show');
                });
                if (!isVisible) {
                    submenu.classList.add('show');
                }
            });
        });
        document.querySelectorAll('.submenu .close-btn').forEach(function(closeBtn) {
            closeBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                this.parentElement.classList.remove('show');
            });
        });
        
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            const mainContent = document.getElementById('main-content');
            
            if (sidebar.style.transform === 'translateX(0%)') {
                sidebar.style.transform = 'translateX(-100%)';
                mainContent.style.marginLeft = '0';
            } else {
                sidebar.style.transform = 'translateX(0%)';
                mainContent.style.marginLeft = '250px';
            }
        }
    </script>
</body>
</html>