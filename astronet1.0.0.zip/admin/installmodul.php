<?php
require("../vendor/autoload.php");
use phpseclib3\Net\SSH2;

if (isset($_POST['id']) && isset($_POST['ip']) && isset($_POST['usuario']) && isset($_POST['senha'])) {
    $id = $_POST['id'];
    $ip = $_POST['ip'];
    $usuario = $_POST['usuario'];
    $senha = $_POST['senha'];

    // Conectar ao servidor via SSH
    $ssh = new SSH2($ip);
    if (!$ssh->login($usuario, $senha)) {
        echo "Falha na conexão SSH!";
        exit;
    }

    // Arquivos para instalação
    $files = [
        'modulcreate.sh',
        'createteste.sh',
        'deleteuser.sh',
        'moduldelete.sh',
        'add.sh',
        'install.sh'
    ];

    // Para cada arquivo, verificar se existe, remover e baixar novamente
    foreach ($files as $file) {
        // Verificar e remover qualquer arquivo existente com o mesmo nome ou versões com ".1", ".2" etc.
        $ssh->exec("rm -f $file");  // Remove o arquivo com o nome exato
        $ssh->exec("rm -f $file.*");  // Remove qualquer versão do arquivo (exemplo: .1, .2, etc.)

        // Baixar o arquivo novamente
        $ssh->exec("wget https://raw.githubusercontent.com/BielZcode1/AstroModulosL/main/install.sh");
        $ssh->exec("chmod 777 install.sh");
        $ssh->exec("chmod +x install.sh");
        $output = $ssh->exec("./install.sh");

        if (!$output) {
            echo "Erro ao executar o arquivo install.sh.";
            exit;
        }
    }

    echo "Instalado com sucesso!";
} else {
    echo "Requisição inválida!";
}
?>
