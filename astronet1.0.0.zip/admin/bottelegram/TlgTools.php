<?php 
session_start();
require '../../astro/conexao.php';

$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

$sql = "SELECT * FROM configs";
$result = $conn -> query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $nomepainel = $row["nomepainel"];
        $logo = $row["logo"];
        $icon = $row["icon"];
        $csspersonali = $row["corfundologo"];
    }
}

$sql1 = "SELECT * FROM bot";
$result1 = $conn -> query($sql1);
if ($result1->num_rows > 0) {
    while($user_data = $result1->fetch_assoc()) {
        $valorlogin = $user_data["valor"];
        $tokentelegram = $user_data["bottoken"];
        $nomeapk = $user_data["app"];
        $tempodeteste = $user_data["tempoteste"];
        $idtell = $user_data["botid"];
    }
}

$sql2 = "SELECT * FROM accounts WHERE id = 1";
$result2 = $conn -> query($sql2);
if ($result2->num_rows > 0) {
    while($user_data = $result2->fetch_assoc()) {
        $tokenvenda = $user_data["tokenvenda"];
    }
}

define('DOMINIO', $_SERVER['HTTP_HOST']); 
define('TOKENVENDA', $tokenvenda); 
define("MP_TOKEN", "seu token do mercado pago aqui");  
define("BOT_TOKEN", $tokentelegram);  
define("VALOR", "0.50"); 
define("SERVIDOR", $ip);  
define("SENHA", $senha); 
define("TESTE_TEMPO", $tempodeteste);  
define("CANAL_ID", $idtell); 
define("APK_NOME", $nomeapk . ".apk"); 
