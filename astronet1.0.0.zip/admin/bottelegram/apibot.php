<?php

require '../../astro/conexao.php'; // Conexão com o banco
require '../../vendor/autoload.php'; // Autoload do Composer
require 'TlgTools.php';
use Telegram\Bot\Api;
use Telegram\Bot\Keyboard\Keyboard;

// Verifica se a conexão já existe
if (!isset($conn)) {
    $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
}

// Captura o domínio do servidor
$dominio = $_SERVER['HTTP_HOST'];

// Recuperar token do bot
$sql1 = "SELECT bottoken FROM bot LIMIT 1";
$result1 = $conn->query($sql1);
$token = $result1->num_rows > 0 ? $result1->fetch_assoc()["bottoken"] : die("Token não encontrado!");

// Recuperar nome do painel
$sql = "SELECT * FROM configs LIMIT 1";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $nomepainel = $result->num_rows > 0 ? $result->fetch_assoc()["nomepainel"] : "AstroBot";
        $logo = $row["logo"];
        $icon = $row["icon"];
        $csspersonali = $row["corfundologo"];
    }
}

// Configuração do Telegram API
$telegram = new Api($token);

// Definir o webhook
$webhookUrl = 'https://' . $dominio . '/admin/bottelegram/apibot.php';
$telegram->setWebhook(['url' => $webhookUrl]);

// Receber atualização do webhook
$update = $telegram->getWebhookUpdates();

// Verificar se há uma mensagem
if (isset($update['message'])) {
    $message = $update['message'];
    $chat_id = $message['chat']['id'];
    $first_name = $message['from']['first_name'] ?? "Usuário";
    $text = $message['text'] ?? "";
    $user_id = $message['from']['id'];

    // Definir saudação com base no horário
    date_default_timezone_set('America/Sao_Paulo');
    $hora_atual = (int)date("H"); // Converte para número inteiro

    if ($hora_atual >= 6 && $hora_atual < 12) {
        $saudacao = "Bom dia";
    } elseif ($hora_atual >= 12 && $hora_atual < 18) {
        $saudacao = "Boa tarde";
    } elseif ($hora_atual >= 18 && $hora_atual < 24) { 
        $saudacao = "Boa noite";
    } else { 
        $saudacao = "Boa madrugada";
    }

    // Mensagem de boas-vindas
    $mensagem = "\n\nClique nas opções desejadas.\n\n◆━━━━━━━━━━━━━━━━━━━━━━━━(✪)━━━━━━━━━━━━━━━━━━━━━━━━◆\n\n"
        . "↪︎ Olá {$first_name}, {$saudacao}\n\n↪︎ Seu ID: $user_id\n\n◆━━━━━━━━━━━━━━━━━━━━━━━━(✪)━━━━━━━━━━━━━━━━━━━━━━━━◆\n\n"
        . "🤖AstroNetBot - (versão 1.0 beta)\n\n"
        . "👋 Bem-vindo ao AstroBot! Escolha uma das opções abaixo:\n\n☑︎ Selecione uma opção";

    // Verifica se o comando é "/start"
    if ($text === '/start') {
        sendMessageWithNewButtons($telegram, $chat_id, $mensagem);
    }
}

// Gerar string aleatória
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    return substr(str_shuffle($characters), 0, $length);
}

// Verificar se há um callback_query
if (isset($update['callback_query'])) {
    $callback_query = $update['callback_query'];
    $chat_id = $callback_query['message']['chat']['id'];
    $callback_data = $callback_query['data']; 

    switch ($callback_data) {
        case 'teste':
            $login = generateRandomString(8);
            $senha = generateRandomString(12);
            $validade = 30;
            $limite = 1; 
            $byid = 1;

            // Inserir os dados no banco
            $stmt = $conn->prepare("INSERT INTO ssh_accounts (login, senha, expira, limite, byid) VALUES (?, ?, ?, ?, ?)");
            if (!$stmt) {
                file_put_contents($log_file, "Erro na preparação do SQL: " . $conn->error . "\n", FILE_APPEND);
            } else {
                $stmt->bind_param("sssss", $login, $senha, $validade, $limite, $byid);
                if ($stmt->execute()) {
                    $telegram->sendMessage([
                        'chat_id' => $chat_id,
                        'text' => "◆━━━━━━━━(✪)━━━━━━━━◆\n\n✅ Sucesso ao criar seu Teste\n\n◆━━━━━━━━(✪)━━━━━━━━◆\n\nAqui está seu teste criado:\n\n🔑 Login: $login\n🔒 Senha: $senha\n\n🕐 Validade: $validade Minutos\n\n🎯 Limite Login: $limite\n\nNão passe suas informações para ninguém."
                    ]);                    
                } else {
                    file_put_contents($log_file, "Erro ao executar SQL: " . $stmt->error . "\n", FILE_APPEND);
                    $telegram->sendMessage([
                        'chat_id' => $chat_id,
                        'text' => "❌ Erro ao criar a conta de teste. Verifique o log."
                    ]);
                }
                $stmt->close();
            }
            break;
        case 'renovrlogin':
            $telegram->sendMessage(['chat_id' => $chat_id, 'text' => "Você escolheu renovar login."]);
            break;
        case 'renovarrevenda':
            $telegram->sendMessage(['chat_id' => $chat_id, 'text' => "Você escolheu renovar revenda."]);
            break;
    }

    $telegram->answerCallbackQuery([
        'callback_query_id' => $callback_query['id'],
        'text' => "Você escolheu: " . $callback_data,
        'show_alert' => false
    ]);
}

// Função para enviar a mensagem com botões inline
function sendMessageWithNewButtons($telegram, $chat_id, $title) {
    $keyboard = Keyboard::make([
        'inline_keyboard' => [
            [
                ['text' => '🕐 CRIAR TESTE, DURA 3 HORAS', 'callback_data' => 'teste'],
                ['text' => '📲 COMPRAR LOGIN', 'url' => 'https://' . DOMINIO . '/planos.php']
            ],
            [['text' => '🛠 RENOVAR LOGIN', 'callback_data' => 'renovrlogin']],
            [['text' => '👤 COMPRAR PAINEL REVENDA', 'url' => 'https://' . DOMINIO . '/revenda.php?token=' . TOKENVENDA]],
            [['text' => '📲 APP STORE', 'url' => 'https://t.me/BielZcode']],
            [['text' => '🙍‍♂️ SUPORTE', 'url' => 'https://t.me/BielZcode']],
        ],
    ]);

    $telegram->sendMessage(['chat_id' => $chat_id, 'text' => $title, 'reply_markup' => $keyboard]);
}

?>
