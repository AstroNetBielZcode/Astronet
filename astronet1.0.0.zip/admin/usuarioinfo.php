<?php
// Incluir a conexão com o banco de dados
include('../astro/conexao.php');

// Verificar se o ID foi passado via GET
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $revendedor_id = $_GET['id'];

    // Conectar ao banco de dados
    $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Preparar a consulta SQL para buscar os dados do revendedor
    $sql = "SELECT * FROM ssh_accounts WHERE id = ?";
    
    // Preparar a consulta
    if ($stmt = $conn->prepare($sql)) {
        // Vincular o parâmetro de ID
        $stmt->bind_param("i", $revendedor_id);
        
        // Executar a consulta
        $stmt->execute();
        
        // Obter o resultado
        $result = $stmt->get_result();

        // Verificar se o revendedor foi encontrado
        if ($result->num_rows > 0) {
            $revendedor = $result->fetch_assoc();
            
            // Retornar os dados do revendedor como JSON
            echo json_encode($revendedor);
        } else {
            echo json_encode(["error" => "Usuario não encontrado."]);
        }
        
        // Fechar a declaração
        $stmt->close();
    } else {
        echo json_encode(["error" => "Erro na consulta ao banco de dados."]);
    }

    // Fechar a conexão com o banco
    $conn->close();
} else {
    echo json_encode(["error" => "ID inválido."]);
}
?>
