<?php
include("../astro/conexao.php"); // Conexão com o banco de dados

try {
    $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
} catch (mysqli_sql_exception $e) {
}

if (isset($_POST['id']) && isset($_POST['nome'])) {
    $id = $_POST['id'];
    $nome = $_POST['nome'];

    // Prepara e executa a atualização no banco de dados
    $sql = "UPDATE categorias SET nome = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $nome, $id);

    if ($stmt->execute()) {
        echo "sucesso";
    } else {
        echo "erro";
    }

    $stmt->close();
}

?>
