<?php

require("../vendor/autoload.php");
use phpseclib3\Net\SSH2;

// Verifica se os parâmetros necessários estão presentes
if (isset($_POST['id']) && isset($_POST['ip']) && isset($_POST['login']) && isset($_POST['senha'])) {
    $id = $_POST['id'];
    $ip = $_POST['ip'];
    $senha = $_POST['senha'];
    $loginSSH = $_POST['login'];

    // Cria a conexão SSH
    $ssh = new SSH2($ip);
    if ($ssh->login($loginSSH, $senha)) {
        // Executa o script para limpar a máquina
        $output = $ssh->exec('bash moduldelete.sh');  // Substitua pelo caminho do script na máquina

        if ($output) {
            echo "Limpeza realizada com sucesso!";
        } else {
            echo "Erro ao executar o script de limpeza.";
        }
    } else {
        echo "Falha na conexão SSH!";
    }
} else {
    echo "Requisição inválida!";
}
?>
