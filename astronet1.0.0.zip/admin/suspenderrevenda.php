<?php
include('../astro/conexao.php');
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['id'])) {
    $revendedor_id = $_GET['id'];

    // Verifica se o ID é válido
    if (is_numeric($revendedor_id)) {
        // Preparar a SQL para suspender o revendedor (zerando a validade)
        $sql = "UPDATE accounts SET validade = 0 WHERE id = ?";
        
        // Preparar a declaração
        if ($stmt = $conn->prepare($sql)) {
            // Vincula o ID do revendedor
            $stmt->bind_param("i", $revendedor_id);

            // Executa a consulta
            if ($stmt->execute()) {
                echo 'success'; // Retorna "success" para o AJAX
            } else {
                echo 'error'; // Retorna "error" caso a execução falhe
            }

            // Fecha a declaração
            $stmt->close();
        }
    } else {
        echo 'invalid'; // Retorna "invalid" caso o ID não seja válido
    }
}

// Fecha a conexão com o banco
$conn->close();
?>
