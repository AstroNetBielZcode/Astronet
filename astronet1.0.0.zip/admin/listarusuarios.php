<?php

error_reporting(0);


session_start();

require '../astro/conexao.php';

require("../vendor/autoload.php");
use Telegram\Bot\Api;
$dominio = $_SERVER['HTTP_HOST'];
$telegram = new Api('8062935114:AAGNw_4YWiADqJeZin3Sh2onooWJCD3T514');
date_default_timezone_set('America/Sao_Paulo');

try {
    $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
} catch (mysqli_sql_exception $e) {
    header('Location: install.php');
    exit;
}

if(!isset($_SESSION['login']) and !isset($_SESSION['senha'])){
    session_destroy();
    unset($_SESSION['login']);
    unset($_SESSION['senha']);
    header('location:../index.php');
}


$sql = "SELECT * FROM configs";
$result = $conn -> query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $nomepainel = $row["nomepainel"];
        $logo = $row["logo"];
        $icon = $row["icon"];
        $csspersonali = $row["corfundologo"];
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="<?php echo $icon; ?>" type="image/x-icon">
    <title><?php echo $nomepainel; ?> - Painel Administrativo</title>

    <!-- Theme -->
    <link rel="stylesheet" href="../app-assets/css/themes/semi-dark-layout.css">
    <link rel="stylesheet" href="../app-assets/css/themes/dark-layout.css">
    <link rel="stylesheet" href="../app-assets/css/components.css">
    <!-- END - Theme -->

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" />


    <!-- DataTables -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.8/css/dataTables.jqueryui.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdn.datatables.net/2.0.3/js/dataTables.js"></script>
    <script src="https://cdn.datatables.net/2.0.3/js/dataTables.bootstrap5.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- END - Bootstrap -->

    <!-- Swal.fire -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@5/dark.css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>

    <!-- END - SweetAlert2 -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">  

    <style>
        <?php echo $csspersonali ?>
    </style>
</head>
<body class="vertical-menu-body bootstrap-color" id="data-value-carregando">
    <div id="rodape" class="rodape-horizontal" style="margin-top: 10px;">
        <div class="footer-nav vertical-texts">
            <button class="btn-open" onclick="toggleSidebar()" id="open-btn"><i class="fa-solid fa-bars"></i></button>
            <button class="btn-primary-sucess m6-0" onclick="criarteste()"><svg class="svgs" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-plus"><circle cx="12" cy="12" r="10"/><path d="M8 12h8"/><path d="M12 8v8"/></svg> Teste Rapido</button>
            <script>
                function criarusuario() {
                    window.location.href = 'criarteste.php';
                }
                function conta() {
                    window.location.href = 'perfil.php';
                }
            </script>
            <div class="avatar bg-success mr-1">
                <div class="perfil-perfomace-primary">
                    <div class="perfil-primary">
                        <div class="perfil" id="perfil">
                            <p onclick="conta()">
                                <img src="<?php echo $icon; ?>" alt="icon">
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Content Menu Create/list -->
     <div class="nav-bar-cat">
     </div>
    <div class="content-wrapper">
        <div class="">
            <div class="">
                <div class="">
                    <div class="">
                        <div class="card">
                            <div class="card-header">
                                <div class="head-label text-center">
                                    <h5 class="card-title mb-0">Listar Usuarios</h5>
                                </div>
                                <div class="dt-action-buttons text-end pt-3 pt-md-0">
                                    <div class="dt-buttons btn-group flex-wrap">
                                            <button onclick="window.location.href='criarusuario.php'" class="btn-create" name="create-cat" type="submit">Adicionar</button>
                                    </div>
                                </div>
                                <div class="bar4"></div>
                            </div>
                            <div class="datatables-basic table border-top dataTable no-footer dtr-column collapsed">
                                <div class="table-responsive">
                                    <table id="example" class="display table " style="width:100%">
                                        <!-- Conteúdo da tabela aqui -->
                                    </table>
                                </div><br>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- AREA MODAL -->
        <div class="area-modal">
            <style>     
                    .modal-content {
                    border-radius: 10px;
                    color: #ffffff;
                    border: none;
                    padding: 20px;
                    max-width: 600px;
                    margin: auto; /* Centraliza o modal */
                }

                /* Alinhamento da tabela */
                .table {
                    color: #ffffff;
                    border-radius: 8px;
                    width: 100%;
                }

                .table th,
                .table td {
                    text-align: left;
                    padding: 12px 20px; /* Aumenta o espaço entre os itens */
                }

                /* Ajustando espaçamento entre os rótulos e os campos */
                .row {
                    margin-bottom: 12px; /* Aumenta a distância entre os elementos */
                }

                /* Estilização dos botões */
                .btn {
                    border-radius: 6px;
                    font-weight: bold;
                    padding: 8px 12px;
                }

                .btn-danger {
                    background-color: #d9534f;
                    border: none;
                }

                .btn-danger:hover {
                    background-color: #c9302c;
                }

                .btn-warning {
                    background-color: #f0ad4e;
                    border: none;
                    color: #fff;
                }

                .btn-warning:hover {
                    background-color: #ec971f;
                }

                /* Footer do modal */
                .modal-footer {
                    border-top: 1px solid #444;
                    padding-top: 15px;
                    text-align: right;
                }

                /* Responsividade */
                @media (max-width: 768px) {
                    .modal-content {
                        width: 90%;
                        padding: 15px;
                    }

                    .table-responsive {
                        overflow-x: auto;
                    }
                }

                /* Estilos de Pesquisa e Entries */

                .pagination a {
                    padding: 5px 10px;
                    margin: 0 5px;
                    text-decoration: none;
                    color: #007bff;
                }

            </style>
            <!-- Modal -->
            <div class="modal fade" id="editarModal" data-bs-backdrop="static">
                <div class="modal-dialog">
                    <form class="modal-content">
                        <div class="modal-body">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Nome</th>
                                            <th>Senha</th>
                                            <th>Validade</th>
                                            <th>Limite</th>
                                            <th>Categoria</th>
                                            <th>Whatsapp</th>
                                            <th>Modo</th>
                                            <th>Status</th>
                                            <th>Apagar</th>
                                            <th>Editar</th>
                                            <th>Reativar</th>
                                            <th>Suspender</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $sql = "SELECT * FROM ssh_accounts WHERE byid = 1"; 
                                            $result = $conn->query($sql);
                                            
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    // Verifica a validade e ajusta o modo
                                                    $modo = $row['expira'] == 0 ? 'Suspenso' : 'Ativado';
                                            
                                                    echo "<tr id='categoria-{$row['id']}'>
                                                            <td>{$row['login']}</td>
                                                            <td>{$row['senha']}</td>
                                                            <td>{$row['expira']}</td>
                                                            <td>{$row['limite']}</td>
                                                            <td>{$row['categoriaid']}</td>
                                                            <td>{$row['whatsapp']}</td>
                                                            <td>{$modo}</td>  <!-- Mostra 'Suspenso' ou 'Ativado' dependendo da validade -->
                                                            <td style='color: #fff;'>{$row['status']}</td>  <!-- Mostra 'Offline' ou 'Online' dependendo do status da pessoa -->
                                                            <td>
                                                                <button type='button' class='btn btn-delete' onclick='deleteUser({$row['id']})'>Apagar</button>
                                                            </td>
                                                            <td>
                                                                <button type='button' class='btn btn-success btn-sm' onclick='editaruser(" . $row['id'] . ")'>Editar</button>
                                                            </td>
                                                            <td>
                                                                <button type='button' class='btn btn-success' onclick='reativar({$row['id']})'>Reativar</button>
                                                            </td>
                                                            <td>
                                                                <button type='button' class='btn btn-success' onclick='suspender(" . $row['id'] . ")'>Suspender</button>
                                                            </td>
                                                        </tr>";
                                                }
                                            }                                            
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!-- SweetAlert2 e jQuery -->
            <!-- jQuery -->
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <!-- SweetAlert2 -->
            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

            <script>
                function deleteUser(id, nome) {
                    event.preventDefault(); // Impede o comportamento padrão (evitar refresh da página)

                    Swal.fire({
                        title: "Tem certeza?",
                        text: "Essa ação não pode ser desfeita!",
                        icon: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#d33",
                        cancelButtonColor: "#3085d6",
                        confirmButtonText: "Sim, excluir!",
                        cancelButtonText: "Cancelar",
                        background: "#1e1e2f", // Fundo escuro
                        color: "#ffffff", // Texto branco
                        customClass: {
                            popup: "swal2-dark",
                            confirmButton: "swal2-dark-btn",
                            cancelButton: "swal2-dark-btn"
                        }
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $.ajax({
                                url: "excluiruser.php",
                                type: "POST",
                                data: { id: id },
                                success: function(response) {
                                    if (response === "success") {
                                        $("#usuario-" + id).fadeOut();
                                        Swal.fire({
                                            title: "Excluído!",
                                            text: "O Usuario foi removido com sucesso.",
                                            icon: "success",
                                            background: "#1e1e2f",
                                            color: "#ffffff"
                                        }).then(() => {
                                            location.reload(); // Realiza o refresh após a confirmação do sucesso
                                        });
                                    } else {
                                        Swal.fire({
                                            title: "Erro!",
                                            text: "Ocorreu um erro ao excluir o Usuario.\n" + response,
                                            icon: "error",
                                            background: "#1e1e2f",
                                            color: "#ffffff"
                                        });
                                    }
                                },
                                error: function() {
                                    Swal.fire({
                                        title: "Erro!",
                                        text: "Falha na comunicação com o Usuario.",
                                        icon: "error",
                                        background: "#1e1e2f",
                                        color: "#ffffff"
                                    });
                                }
                            });
                        }
                    });
                };
            </script>
            <script>
                function suspender(id) {
                    Swal.fire({
                        title: 'Tem certeza?',
                        text: 'Você não poderá reverter isso!',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Suspender',
                        color: "#ffffff",
                        background: "#1e1e2f",
                        cancelButtonText: 'Cancelar'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // Faz a requisição AJAX
                            $.ajax({
                                url: 'suspenderusuario.php',
                                method: 'GET',
                                data: { id: id },
                                success: function(response) {
                                    if (response == 'success') {
                                        Swal.fire({
                                            title: 'Usuário suspenso!',
                                            text: 'O usuario foi suspneso.',
                                            color: "#ffffff",
                                            background: "#1e1e2f",
                                            icon: 'success'
                                        }).then(() => {
                                            // Aqui você pode, em vez de remover a linha, fazer uma nova chamada AJAX para recarregar a lista
                                            carregarTabela(); // Atualiza a tabela sem recarregar a página
                                            location.reload(); // Recarrega a página
                                        });
                                    } else if (response == 'error') {
                                        Swal.fire({
                                            title: 'Erro!',
                                            text: 'Não foi possível suspender o usuário.',
                                            icon: 'error',
                                            color: "#ffffff",
                                            background: "#1e1e2f"
                                        });
                                    } else if (response == 'invalid') {
                                        Swal.fire({
                                            title: 'Erro!',
                                            text: 'ID inválido.',
                                            icon: 'error',
                                            color: "#ffffff",
                                            background: "#1e1e2f"
                                        });
                                    }
                                },
                                error: function() {
                                    Swal.fire({
                                        title: 'Erro!',
                                        text: 'Erro na requisição.',
                                        icon: 'error',
                                        color: "#ffffff",
                                        background: "#1e1e2f"
                                    });
                                }
                            });
                        }
                    });
                }


                function carregarTabela() {
                    $.ajax({
                        url: 'listarusuarios.php', // Aqui, a URL onde você lista os revendedores
                        success: function(response) {
                            // Atualiza a tabela com os novos dados
                            $('#tabela-usuarios').html(response); // 'tabela-revendedores' é o id da tabela onde os revendedores estão listados
                        }
                    });
                }

            </script>

            <script>
                function reativar(id) {
                Swal.fire({
                    title: 'Tem certeza?',
                    text: 'Você deseja reativar este Usuario?',
                    icon: 'warning',
                    showCancelButton: true,
                    color: "#ffffff",
                    background: "#1e1e2f",
                    confirmButtonText: 'Reativar',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Faz a requisição AJAX
                        $.ajax({
                            url: 'reativarusuario.php', // A URL para reativar o revendedor
                            method: 'GET',
                            data: { id: id },
                            success: function(response) {
                                if (response == 'success') {
                                    Swal.fire({
                                        title: 'Usuario reativado!',
                                        text: 'Reativado com Sucesso.',
                                        color: "#ffffff",
                                        background: "#1e1e2f",
                                        icon: 'success'
                                    }).then(() => {
                                        // Atualiza a tabela de revendedores
                                        carregarTabela();
                                        location.reload(); // Recarrega a página
                                    });
                                } else if (response == 'error') {
                                    Swal.fire({
                                        title: 'Erro!',
                                        text: 'Não foi possível reativar o Usuario.',
                                        color: "#ffffff",
                                        background: "#1e1e2f",
                                        icon: 'error'
                                    });
                                } else if (response == 'invalid') {
                                    Swal.fire({
                                        title: 'Erro!',
                                        text: 'ID inválido.',
                                        icon: 'error'
                                    });
                                }
                            }
                        });
                    }
                });
            }

            </script>

            <script>
            function editaruser(id) {
                // Faz requisição AJAX para obter os dados do revendedor
                $.ajax({
                    url: 'usuarioinfo.php', // Arquivo PHP que busca os dados
                    type: 'GET',
                    data: { id: id },
                    dataType: 'json', // Recebe a resposta em JSON
                    success: function(usuario) {
                        if (usuario.erro) {
                            Swal.fire('Erro!', usuario.erro, 'error');
                            return;
                        }

                        // Abre o SweetAlert com os dados carregados
                        Swal.fire({
                            title: 'Editar Usuario',
                            html: `
                                <input id="login" class="swal2-input" placeholder="Login" value="${usuario.login}">
                                <input id="senha" class="swal2-input" placeholder="Senha" value="${usuario.senha}">
                                <input id="whatsapp" class="swal2-input" placeholder="Whatsapp" value="${usuario.whatsapp}">
                                <input id="limite" class="swal2-input" placeholder="Limite" value="${usuario.limite}">
                                <input id="valor" class="swal2-input" placeholder="Valor" value="${usuario.valor}">
                                <input id="expira" class="swal2-input" placeholder="Validade" value="${usuario.expira}">
                                <input id="renovacao_periodo" class="swal2-input" placeholder="Renovação Período" value="${usuario.renovacao_periodo}">
                            `,
                            showCancelButton: true,
                            confirmButtonText: 'Salvar',
                            cancelButtonText: 'Cancelar',
                            color: "#ffffff",
                            background: "#1e1e2f",
                            color: "#ffffff",
                            preConfirm: () => {
                                return {
                                    id: id,
                                    login: document.getElementById('login').value,
                                    senha: document.getElementById('senha').value,
                                    whatsapp: document.getElementById('whatsapp').value,
                                    limite: document.getElementById('limite').value,
                                    valor: document.getElementById('valor').value,
                                    expira: document.getElementById('expira').value,
                                    renovacao_periodo: document.getElementById('renovacao_periodo').value
                                };
                            }
                        }).then((result) => {
                            if (result.isConfirmed) {
                                // Faz a requisição para atualizar os dados
                                $.ajax({
                                    url: 'editarusuario.php',
                                    type: 'POST',
                                    data: result.value,
                                    success: function(response) {
                                        var data = JSON.parse(response);
                                        if (data.status === 'success') {
                                            Swal.fire({
                                                title: 'Sucesso!',
                                                text: data.message,
                                                icon: 'success',
                                                background: '#2c2f3e', // Tema escuro
                                                color: '#ffffff', // Cor do texto
                                                confirmButtonColor: '#4CAF50' // Cor do botão de confirmação
                                            }).then(() => {
                                                // Atualiza a tabela de revendedores
                                                carregarTabela();
                                                location.reload(); // Recarrega a página
                                            });
                                        } else {
                                            Swal.fire({
                                                title: 'Erro!',
                                                text: data.message,
                                                icon: 'error',
                                                background: '#2c2f3e', // Tema escuro
                                                color: '#ffffff', // Cor do texto
                                                confirmButtonColor: '#f44336' // Cor do botão de confirmação (vermelho)
                                            });
                                        }
                                    },
                                    error: function(xhr, status, error) {
                                        Swal.fire({
                                            title: 'Erro!',
                                            text: 'Erro na requisição ao servidor: ' + error,
                                            icon: 'error',
                                            background: '#2c2f3e', // Tema escuro
                                            color: '#ffffff', // Cor do texto
                                            confirmButtonColor: '#f44336' // Cor do botão de confirmação (vermelho)
                                        });
                                    }
                                });
                            }
                        });
                    },
                    error: function() {
                        Swal.fire('Erro!', 'Não foi possível obter os dados do Usuario.', 'error');
                    }
                });
            }

            </script>

        </div>
    </div>
        
    <div class="sidebar">
        <img onclick="voltar()" src="<?php echo $logo; ?>" alt="logo">
        <script>
            function voltar() {
                    window.location.href = 'home.php';
            }
        </script>
        <div class="close-sidebar">
            <button class="close-btn" onclick="toggleSidebar()"><span><i class="fa-solid fa-xmark"></i></span></button>
        </div>
        <ul>
            <li class="inicio"><a href="home.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-house"><path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>Início</a></li>
            <li class="has-submenu">
                <a><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-users"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>Usuarios<svg class="arrow"xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-right"><path d="m9 18 6-6-6-6"/></svg></a>
                <ul class="submenu">
                    <li><a href="criarusuario.php">Criar Usuário</a></li>
                    <li><a href="listarbots.php">Criar Teste</a></li>
                    <li><a href="listarusuarios.php">Listar Usuários</a></li>
                    <li><a href="listarusuariosglobal.php">Listar Global</a></li>
                </ul>
            </li>
            <li class="has-submenu">
                <a><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-users-round"><path d="M18 21a8 8 0 0 0-16 0"/><circle cx="10" cy="8" r="5"/><path d="M22 20c0-3.37-2-6.5-4-8a5 5 0 0 0-.45-8.3"/></svg>Revendedores<svg class="arrow"xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-right"><path d="m9 18 6-6-6-6"/></svg></a>
                <ul class="submenu">
                    <li><a href="criarreven.php">Criar Revenda</a></li>
                    <li><a href="listarreven.php">Listar Revendas</a></li>
                    <li><a href="listartodosrevendas.php">Listar Global</a></li>
                </ul>
            </li>
            <li class="has-submenu">
                <a><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-layers-3"><path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m6.08 9.5-3.5 1.6a1 1 0 0 0 0 1.81l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9a1 1 0 0 0 0-1.83l-3.5-1.59"/><path d="m6.08 14.5-3.5 1.6a1 1 0 0 0 0 1.81l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9a1 1 0 0 0 0-1.83l-3.5-1.59"/></svg>Servidores<svg class="arrow"xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-right"><path d="m9 18 6-6-6-6"/></svg></a>
                <ul class="submenu">
                    <li><a href="criarservidor.php">Adicionar Servidor</a></li>
                    <li><a href="listarservidores.php">Listar Servidores</a></li>
                </ul>
            </li>
            <li>
                <a href="listarcategorias.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-layout-grid"><rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/></svg>Categorias</a>
            </li>
            <li>
                <a href="perfil.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user-pen"><path d="M11.5 15H7a4 4 0 0 0-4 4v2"/><path d="M21.378 16.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z"/><circle cx="10" cy="7" r="4"/></svg>Perfil</a>
            </li>
            <li class="has-submenu">
                <a><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-credit-card"><rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/></svg>Pagamentos<svg class="arrow"xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-right"><path d="m9 18 6-6-6-6"/></svg></a>
                <ul class="submenu">
                    <li><a href="configPag.php">Configurar</a></li>
                    <li><a href="listarPlanos.php">Planos</a></li>
                    <li><a href="cupom.php">Cupom</a></li>
                    <li><a href="vendas.php">Vendas</a></li>
                </ul>
            </li>
            <li>
                <a href="configAdmin.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-settings"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>Administração</a>
            </li>
            <li>
                <a href="lojaApks.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-store"><path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"/><path d="M2 7h20"/><path d="M22 7v3a2 2 0 0 1-2 2a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 16 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 12 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 8 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 4 12a2 2 0 0 1-2-2V7"/></svg>Lista de apks</a>
            </li>
            <li>
                <a href="editarcss.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-brush"><path d="m9.06 11.9 8.07-8.06a2.85 2.85 0 1 1 4.03 4.03l-8.06 8.08"/><path d="M7.07 14.94c-1.66 0-3 1.35-3 3.02 0 1.33-2.5 1.52-2 2.02 1.08 1.1 2.49 2.02 4 2.02 2.2 0 4-1.8 4-4.04a3.01 3.01 0 0 0-3-3.02z"/></svg>Editar css</a>
            </li>
            <li>
                <a href="checkuser.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user-round-check"><path d="M2 21a8 8 0 0 1 13.292-6"/><circle cx="10" cy="8" r="5"/><path d="m16 19 2 2 4-4"/></svg>CheckUser</a>
            </li>
            <li>
                <a href="whatsauto.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-phone"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>Whats Auto</a>
            </li>
            <li>
                <a href="whatsapi.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-phone"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>Whats Api</a>
            </li>
            <li>
                <a href="bot.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-send"><path d="M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z"/><path d="m21.854 2.147-10.94 10.939"/></svg>Bot Telegram</a>
            </li>
            <li>
                <a href="logs.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-door-open"><path d="M13 4h3a2 2 0 0 1 2 2v14"/><path d="M2 20h3"/><path d="M13 20h9"/><path d="M10 12v.01"/><path d="M13 4.562v16.157a1 1 0 0 1-1.242.97L5 20V5.562a2 2 0 0 1 1.515-1.94l4-1A2 2 0 0 1 13 4.561Z"/></svg>Logs</a>
            </li>
            <li><a href="../../logout.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-log-out"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>Sair</a></li>
            <li><a href="">Em Breve</a></li>
        </ul>
    </div>
    <footer>
        <p></p>
    </footer>
    <script>
        document.querySelectorAll('.has-submenu > a').forEach(function(menuLink) {
            menuLink.addEventListener('click', function(e) {
                e.preventDefault();
                var submenu = this.nextElementSibling;
                var isVisible = submenu.classList.contains('show');
                document.querySelectorAll('.submenu').forEach(function(sub) {
                    sub.classList.remove('show');
                });
                if (!isVisible) {
                    submenu.classList.add('show');
                }
            });
        });
        document.querySelectorAll('.submenu .close-btn').forEach(function(closeBtn) {
            closeBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                this.parentElement.classList.remove('show');
            });
        });
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            const mainContent = document.getElementById('main-content');
            
            if (sidebar.style.transform === 'translateX(0%)') {
                sidebar.style.transform = 'translateX(-100%)';
                mainContent.style.marginLeft = '0';
            } else {
                sidebar.style.transform = 'translateX(0%)';
                mainContent.style.marginLeft = '250px';
            }
        }

    </script>
    <script src="../app-assets/sweetalert.min.js"></script>
</body>
</html>