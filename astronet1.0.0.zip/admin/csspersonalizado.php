<?php
include('../astro/conexao.php');
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    }

$sql = "SELECT * FROM configs";
$result = $conn -> query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $csspersonali = $row["corfundologo"];
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Lê os dados JSON
    $inputData = json_decode(file_get_contents('php://input'), true);

    if (isset($inputData['function']) && $inputData['function'] === 'save_css') {
        // Salva o CSS no banco de dados
        $css = $inputData['dados'];
        $sql = "UPDATE configs SET corfundologo = ? WHERE id = 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $css);
        if ($stmt->execute()) {
            echo json_encode(['success' => 'CSS atualizado']);
        } else {
            echo json_encode(['error' => 'Erro ao atualizar o CSS']);
        }
        $stmt->close();
        $conn->close();
    }
} else {
    // Retorna o CSS salvo no banco de dados
    $sql = "SELECT * FROM configs";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $csspersonali = $row["corfundologo"];
        }
        echo json_encode($csspersonali);
    }
}

?>

